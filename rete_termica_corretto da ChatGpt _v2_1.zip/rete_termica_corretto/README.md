# Rete Termica Magneti Superconduttori – versione corretta (base modulare)

## Avvio

```bash
python -m pip install -r requirements.txt
python run_gui.py
```

La GUI richiede PySide6 e Matplotlib. Il solver CLI è avviabile con `python run_cli.py`.

## Modifiche principali

- Curve cryocooler: importazione CSV/XLSX oppure inserimento manuale da GUI di coppie `T_K, Q_cap_W`. Le curve 1D sono interpolate con PCHIP; fuori dominio il calcolo si arresta per default. Se si abilita l'estrapolazione, viene usata una tangente lineare agli estremi e viene emesso un warning. Non viene ricostruita alcuna capacità frigorifera non fornita.
- Mappe 2D: seconda coordinata esplicitamente distinta tra temperatura dell'altro stadio (K) e carico dell'altro stadio (W). CSV con colonne `T_K`, `Q_cap_W` e `t_other_k` oppure `q_other_w`/`var2_w`.
- Current leads: ramo `current_lead_1d` con soluzione BVP distribuita, k(T), rho_e(T), Joule generato lungo il conduttore, flussi distinti ai due terminali e profilo T(x). Il nodo stage1 può essere usato come intercetta collegando due segmenti separati.
- MLI: modello `modified_lockheed_nasa2004` basato su NASA/TM-2004-213175 Eq. (13), più modalità `effective_k_literature`, `emissivity_eff` e tabella sperimentale CSV. I parametri d'installazione (numero strati, densità, pressione interstiziale, emissività e fattore di degradazione) sono configurabili.
- Contatti: modello CMY generico per coppie materiali selezionate, dipendente da k(T), pressione, rugosità RMS, microdurezza e pendenza asperità. Il preset legacy Cu-Cu resta disponibile come stima nominale non calibrata.
- Collegamenti bulk + interfaccia: nuovo ramo `conduction_contact_series`, che risolve la temperatura di interfaccia imponendo lo stesso flusso in conduzione e nel contatto. La presenza di rami `conduction` e `contact` paralleli sugli stessi due nodi genera un errore di validazione.
- Transitorio: i nodi con massa nulla sono trattati come nodi algebrici (bilancio stazionario risolto a ogni chiamata del sistema ODE); i nodi con massa positiva sono dinamici.
- Progetti: le curve 1D e le mappe 2D del cryocooler vengono salvate nel JSON, oltre ai parametri di rami e carichi.

## Formato dei file

### Curve cryocooler 1D

CSV con almeno due righe e colonne:

```csv
T_K,Q_cap_W
4.2,1.0
6.0,2.8
10.0,5.4
```

Le capacità devono essere non negative e le temperature univoche. I dati devono riferirsi alla frequenza, configurazione e condizioni dichiarate dal costruttore.

### Proprietà materiale per current leads

CSV con colonne `T`, `k`, `cp` e `rho_e`; unità SI: K, W/(m K), J/(kg K), ohm m. Per il ramo current lead sono obbligatorie `k(T)` e `rho_e(T)`. Non usare una resistività elettrica di rame generica se il materiale reale ha RRR, campo magnetico o composizione differenti.

## Limitazioni note/non validate

1. Il current lead è un BVP 1D a sezione costante, senza scambio radiativo/gassoso distribuito, giunti elettrici, effetto Peltier/Thomson o modello elettrotermico HTS dettagliato.
2. Modified Lockheed è semiempirico e specifico per la configurazione di MLI di riferimento; il CMY è una stima generica e richiede dati superficiali reali. Entrambi devono essere validati rispetto alla costruzione effettiva.
3. La mappa cryocooler non può essere estrapolata in modo fisicamente affidabile senza dati del costruttore. L'estrapolazione lineare o il nearest-neighbour della mappa 2D sono solo opzioni numeriche segnalate.
4. Il transitorio usa capacità termiche lumped `m cp(T)` e nodi algebrici; non include gradienti interni nelle masse, dipendenza del cryocooler dalla velocità di raffreddamento, né transitori interni del refrigeratore.
5. Le proprietà materiali integrate di default sono curve illustrative da verificare. Per analisi di progetto importare file tracciabili e documentati.
6. Il JSON salva i parametri e le mappe del cryocooler ma non incorpora ancora i file esterni di proprietà materiali: per riprodurre il progetto occorre conservare anche i CSV/XLSX dei materiali.
7. Non è stata eseguita una validazione sperimentale del modello complessivo su un magnete reale. La convergenza numerica non dimostra la correttezza fisica.

## Riferimenti per i preset

- ASHRAE Handbook – Cryogenics, tabelle sulle conducibilità apparenti di MLI evacuato (valori riportati per specifiche densità di strati e pressione residua).
- NASA, *Thermal Performance of Cryogenic Multilayer Insulation at Various Layer Spacings*, NASA NTRS document 20100034929: evidenzia la dipendenza da layer density, numero di strati, spacer e pressione.
- Mykhaylyk et al., *Thermal conductance of demountable in vacuum copper-copper joint between 14 and 100 K*, Rev. Sci. Instrum. 83, 034902 (2012), DOI: 10.1063/1.3697693.
- *Experimental estimation of thermal contact conductance across pressed copper-copper contacts at cryogenic-temperatures*, Applied Thermal Engineering 219 (2023), DOI: 10.1016/j.applthermaleng.2022.119412.
- *Thermal contact conductance of various metal interfaces at cryogenic temperature*, International Journal of Nanotechnology 16 (2019), DOI: 10.1504/IJNT.2019.104464.

I preset non sostituiscono i dati sperimentali dei contatti e del sistema MLI effettivamente costruito.


## Modelli fisici avanzati (aggiornamento 2.1)

### Current leads distribuite 1D
Il ramo `current_lead_1d` risolve con collocazione (`scipy.integrate.solve_bvp`)

`d/dx(k(T) A dT/dx) + I^2 rho_e(T)/A = 0`

con temperature imposte ai due nodi estremi. Il nodo intermedio della rete realizza l'intercetta termica: per una lead 300 K→stage 1→stage 2 creare due segmenti indipendenti, uno ambiente-stage1 e uno stage1-stage2. La rete usa separatamente il flusso ai due estremi; la differenza eguaglia la potenza Joule integrata. Il profilo `T(x)` è conservato in `network.current_lead_profiles`. Le tabelle materiali devono contenere `k(T)` [W/(m K)] e `rho_e(T)` [ohm m].

### MLI Modified Lockheed
La modalità `modified_lockheed_nasa2004` implementa NASA/TM-2004-213175, Eq. (13), con tre contributi: conduzione solida del Dacron, radiazione fra schermi DAM perforati e conduzione del gas in regime molecolare libero. La pressione immessa è in Pa e viene convertita in torr per la correlazione NASA. La correlazione è specifica della configurazione/materiali testati; non va trasferita senza calibrazione a MLI con spacer, metallizzazione, perforazioni o compressione differenti. Il fattore di degradazione consente di rappresentare penalizzazioni d'installazione, ma deve essere giustificato. È possibile inserire un blanket a densità variabile tramite segmenti nel formato `N_strati:densità;N_strati:densità`; per esempio `10:8;15:12;20:16` riproduce la suddivisione a tre segmenti descritta nel caso MHTB NASA, non un preset universale.

### Contatti termici
`CMY_generic` implementa una stima Cooper-Mikic-Yovanovich dipendente da k(T) dei due materiali, pressione, rugosità RMS combinata, microdurezza della superficie più tenera e pendenza delle asperità. Non è una correlazione criogenica specifica calibrata per ogni coppia. Per Cu-Cu e Al1070-Al1070 esistono dati 10–70 K a 6–13.5 MPa; per SS304-Cu e SS304-SS304 esistono dati 70–290 K a 0.2–0.7 MPa. In mancanza dei coefficienti sperimentali completi, il programma non attribuisce a queste coppie valori fittizi: il CMY resta una stima con input superficiali espliciti.

## Limitazioni importanti
- Le current leads sono 1D monodimensionali, a sezione costante e senza scambio radiativo/gassoso distribuito. Contatti elettrici, giunti, effetto Peltier/Thomson, dipendenza da campo magnetico e stabilità elettrotermica non sono inclusi.
- Il modello MLI è semiempirico e non risolve ogni schermo come nodo; la pressione è assunta uniforme. Penetrazioni, cuciture e ponti termici sono rappresentati solo tramite fattori aggiuntivi.
- CMY richiede dati superficiali reali. Durezza, rugosità e slope non vanno scelti come numeri arbitrari per un dimensionamento finale.
