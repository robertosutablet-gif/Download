from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from materials.library import MaterialLibrary
from physics.conduction import conduction_heat_flow
from physics.contacts import contact_heat_flow, cmy_contact_conductance
from physics.radiation import radiation_heat_flow
from physics.mli import MLIModel
from physics.cryocooler import TwoStageCryocooler
from physics.current_lead import solve_current_lead_1d


@dataclass
class ThermalNode:
    id: str
    node_type: str = "thermal_mass"
    fixed_temp_K: Optional[float] = None
    material: Optional[str] = None
    mass_kg: float = 0.0
    target_temp_K: Optional[float] = None


@dataclass
class ThermalBranch:
    id: str
    branch_type: str  # "conduction" | "contact" | "radiation" | "mli"
    from_node: str
    to_node: str
    params: Dict = field(default_factory=dict)
    enabled: bool = True


@dataclass
class HeatLoad:
    id: str
    node: str
    power_W: float
    category: str = "internal"
    source: str = "user"
    enabled: bool = True


class ThermalNetwork:
    def __init__(
        self,
        name: str = "Superconducting_Magnet_Network",
        ambient_temp_K: float = 293.15,
        materials: Optional[MaterialLibrary] = None,
        cryocooler: Optional[TwoStageCryocooler] = None,
    ) -> None:
        self.name = name
        self.ambient_temp_K = float(ambient_temp_K)
        self.materials = materials or MaterialLibrary()
        self.cryocooler = cryocooler or TwoStageCryocooler()
        self.nodes: Dict[str, ThermalNode] = {}
        self.branches: List[ThermalBranch] = []
        self.loads: List[HeatLoad] = []
        self._mli_cache: Dict[str, MLIModel] = {}
        self.current_lead_profiles: Dict[str, Dict] = {}

    def add_node(self, node: ThermalNode) -> None:
        self.nodes[node.id] = node

    def add_branch(self, branch: ThermalBranch) -> None:
        self.branches.append(branch)

    def add_load(self, load: HeatLoad) -> None:
        self.loads.append(load)

    def validate_graph(self) -> List[str]:
        issues: List[str] = []
        if not self.nodes:
            issues.append("Nessun nodo definito nella rete.")
        for b in self.branches:
            if b.from_node not in self.nodes:
                issues.append(f"Ramo '{b.id}': nodo origine '{b.from_node}' inesistente.")
            if b.to_node not in self.nodes:
                issues.append(f"Ramo '{b.id}': nodo destinazione '{b.to_node}' inesistente.")
            if b.from_node == b.to_node:
                issues.append(f"Ramo '{b.id}': auto-anello sullo stesso nodo '{b.from_node}'.")
        for ld in self.loads:
            if ld.node not in self.nodes:
                issues.append(f"Carico '{ld.id}': nodo '{ld.node}' inesistente.")
        # Avviso: contatto e conduzione sullo stesso paio di nodi sono sommati in parallelo.
        pairs={}
        for b in self.branches:
            if b.enabled:
                key=frozenset((b.from_node,b.to_node)); pairs.setdefault(key,[]).append(b.branch_type)
        for pair,types in pairs.items():
            if "contact" in types and "conduction" in types:
                issues.append(f"Possibile errore topologico tra {sorted(pair)}: conduzione e contatto sono rami paralleli. Se rappresentano un unico giunto usare conduction_contact_series.")
        return issues

    def unknown_nodes(self) -> List[ThermalNode]:
        return [n for n in self.nodes.values() if n.fixed_temp_K is None]

    def _get_mli_model(self, branch: ThermalBranch) -> MLIModel:
        p = branch.params
        key = f"{branch.id}_{p.get('mode', 'parametric_modified_lockheed')}_{p.get('exp_csv_path', '')}"
        if key not in self._mli_cache:
            self._mli_cache[key] = MLIModel(
                mode=p.get("mode", "modified_lockheed_nasa2004"),
                area_m2=float(p.get("area_m2", 1.0)),
                layers=int(p.get("layers", 45)),
                layer_density_per_cm=float(p.get("layer_density_per_cm", 12.0)),
                residual_pressure_Pa=float(p.get("residual_pressure_Pa", 1e-4)),
                emissivity_eff=float(p.get("emissivity_eff", 0.04)),
                parasitic_W=float(p.get("parasitic_W", 0.0)),
                effective_k_WmK=float(p.get("effective_k_WmK", 3.5e-5)),
                thickness_m=float(p.get("thickness_m", 0.03)),
                degradation_factor=float(p.get("degradation_factor", 1.0)),
                radiation_multiplier=float(p.get("radiation_multiplier", 1.0)),
                solid_multiplier=float(p.get("solid_multiplier", 1.0)),
                gas_multiplier=float(p.get("gas_multiplier", 1.0)),
                gas_coefficient=float(p.get("gas_coefficient", 1.46e4)),
                segments=p.get("segments"),
                allow_extrapolation=bool(p.get("allow_extrapolation", False)),
                exp_csv_path=p.get("exp_csv_path"),
            )
        else:
            m = self._mli_cache[key]
            m.area_m2 = float(p.get("area_m2", m.area_m2))
            m.layers = int(p.get("layers", m.layers))
            m.layer_density_per_cm = float(p.get("layer_density_per_cm", m.layer_density_per_cm))
            m.residual_pressure_Pa = float(p.get("residual_pressure_Pa", m.residual_pressure_Pa))
            m.emissivity_eff = float(p.get("emissivity_eff", m.emissivity_eff))
            m.parasitic_W = float(p.get("parasitic_W", m.parasitic_W))
            m.degradation_factor = float(p.get("degradation_factor", m.degradation_factor))
            m.radiation_multiplier = float(p.get("radiation_multiplier", m.radiation_multiplier))
            m.solid_multiplier = float(p.get("solid_multiplier", m.solid_multiplier))
            m.gas_multiplier = float(p.get("gas_multiplier", m.gas_multiplier))
            m.gas_coefficient = float(p.get("gas_coefficient", m.gas_coefficient))
            m.segments = p.get("segments", m.segments)
            m.effective_k_WmK = float(p.get("effective_k_WmK", m.effective_k_WmK))
            m.thickness_m = float(p.get("thickness_m", m.thickness_m))
            m.allow_extrapolation = bool(p.get("allow_extrapolation", m.allow_extrapolation))
            m._validate()
        return self._mli_cache[key]

    def eval_branch_flow(self, branch: ThermalBranch, temps: Dict[str, float]) -> float:
        if not branch.enabled:
            return 0.0
        Ta = temps[branch.from_node]
        Tb = temps[branch.to_node]
        p = branch.params
        btype = branch.branch_type

        if btype == "conduction":
            mat = self.materials.get(p["material"])
            return conduction_heat_flow(
                Ta,
                Tb,
                area_m2=float(p["area_m2"]),
                length_m=float(p["length_m"]),
                material=mat,
            )
        if btype == "conduction_contact_series":
            mat=self.materials.get(p["material"])
            area=float(p["area_m2"]); length=float(p["length_m"])
            g=p.get("conductance_WK")
            if g is None and p.get("preset")=="CMY_generic":
                ma=self.materials.get(p["material_a"]); mb=self.materials.get(p["material_b"])
                g=cmy_contact_conductance(material_a=ma,material_b=mb,temperature_K=0.5*(Ta+Tb),
                    pressure_MPa=float(p["pressure_MPa"]),area_m2=float(p.get("contact_area_m2",area)),
                    roughness_um=float(p["roughness_um"]),hardness_MPa=float(p["hardness_MPa"]),
                    asperity_slope=float(p.get("asperity_slope",0.1)))
            elif g is None:
                from physics.contacts import preset_contact_conductance
                g=preset_contact_conductance(p["preset"],float(p.get("pressure_MPa",1.0)),float(p.get("contact_area_m2",area)),float(p.get("pressure_exponent",0.8)))
            hot=max(Ta,Tb); cold=min(Ta,Tb)
            if abs(hot-cold)<1e-12: return 0.0
            # Bisezione della temperatura all'interfaccia: conduzione bulk = contatto.
            lo,hi=cold,hot
            for _ in range(80):
                mid=0.5*(lo+hi)
                qbulk=(area/length)*mat.integrate_k(mid,hot)
                qcontact=float(g)*(mid-cold)
                if qbulk>qcontact: lo=mid
                else: hi=mid
            q=(area/length)*mat.integrate_k(0.5*(lo+hi),hot)
            return q if Ta>Tb else -q

        if btype == "contact":
            g = p.get("conductance_WK")
            r = p.get("resistance_KW")
            if p.get("model") == "CMY_generic":
                ma = self.materials.get(p["material_a"]); mb = self.materials.get(p["material_b"])
                g = cmy_contact_conductance(material_a=ma, material_b=mb,
                    temperature_K=0.5*(Ta+Tb), pressure_MPa=float(p["pressure_MPa"]),
                    area_m2=float(p["area_m2"]), roughness_um=float(p["roughness_um"]),
                    hardness_MPa=float(p["hardness_MPa"]), asperity_slope=float(p.get("asperity_slope",0.1)))
            elif p.get("preset") and g is None and r is None:
                from physics.contacts import preset_contact_conductance
                g = preset_contact_conductance(p["preset"], float(p.get("pressure_MPa", 1.0)), float(p.get("area_m2", 1e-4)),float(p.get("pressure_exponent",0.8)))
            return contact_heat_flow(Ta, Tb, conductance_WK=float(g) if g is not None else None,
                                     resistance_KW=float(r) if r is not None else None)
        if btype in ("current_lead", "current_lead_1d"):
            mat = self.materials.get(p["material"])
            lead = solve_current_lead_1d(Ta, Tb, area_m2=float(p["area_m2"]), length_m=float(p["length_m"]),
                current_A=float(p["current_A"]), material=mat, n_points=int(p.get("n_points",41)))
            self.current_lead_profiles[branch.id] = {"x_m":lead.x_m.tolist(),"T_K":lead.T_K.tolist(),
                "q_hot_end_W":lead.q_hot_end_W,"q_cold_end_W":lead.q_cold_end_W,"joule_total_W":lead.joule_total_W}
            return lead.q_hot_end_W
        if btype == "radiation":
            return radiation_heat_flow(
                Ta,
                Tb,
                area_m2=float(p["area_m2"]),
                emissivity_eff=float(p["emissivity_eff"]),
                view_factor=float(p.get("view_factor", 1.0)),
            )
        if btype == "mli":
            mli = self._get_mli_model(branch)
            return mli.heat_flow(Ta, Tb)

        raise ValueError(f"Tipo di ramo non supportato: '{btype}'.")

    def evaluate_balances(
        self, temps: Dict[str, float]
    ) -> Tuple[Dict[str, float], List[Dict], Dict[str, float], List[str]]:
        warnings: List[str] = []
        net_in_W: Dict[str, float] = {nid: 0.0 for nid in self.nodes}
        gen_W: Dict[str, float] = {nid: 0.0 for nid in self.nodes}
        cool_W: Dict[str, float] = {nid: 0.0 for nid in self.nodes}
        branch_rows: List[Dict] = []

        self.current_lead_profiles = {}
        for b in self.branches:
            q_joule_W = 0.0
            if b.enabled and b.branch_type == "contact" and b.params.get("model") == "CMY_generic":
                warnings.append(f"Contatto '{b.id}': CMY generico; validare rugosità, durezza e conduttanza con dati sperimentali della coppia reale.")
            if b.enabled and b.branch_type == "mli" and b.params.get("mode", "modified_lockheed_nasa2004") == "modified_lockheed_nasa2004":
                tlo=min(temps[b.from_node],temps[b.to_node]); thi=max(temps[b.from_node],temps[b.to_node])
                if tlo < 20.0 or thi > 305.0:
                    warnings.append(f"MLI '{b.id}': NASA/TM-2004-213175 Eq. (13) usata fuori dal campo di confronto principale 20-305 K; verificare/validare l'estrapolazione.")
            if b.enabled and b.branch_type in ("current_lead", "current_lead_1d"):
                p=b.params; mat=self.materials.get(p["material"])
                lead=solve_current_lead_1d(temps[b.from_node],temps[b.to_node],
                    area_m2=float(p["area_m2"]),length_m=float(p["length_m"]),
                    current_A=float(p["current_A"]),material=mat,n_points=int(p.get("n_points",41)))
                # Separate boundary heat rates: q_cold-q_hot equals distributed Joule generation.
                net_in_W[b.from_node] -= lead.q_hot_end_W
                net_in_W[b.to_node] += lead.q_cold_end_W
                q_ft=lead.q_hot_end_W; q_joule_W=lead.joule_total_W
                self.current_lead_profiles[b.id]={"x_m":lead.x_m.tolist(),"T_K":lead.T_K.tolist(),
                    "q_hot_end_W":lead.q_hot_end_W,"q_cold_end_W":lead.q_cold_end_W,
                    "joule_total_W":lead.joule_total_W}
            else:
                q_ft = self.eval_branch_flow(b, temps)
                net_in_W[b.from_node] -= q_ft
                net_in_W[b.to_node] += q_ft
            branch_rows.append({"id":b.id,"type":b.branch_type,"from":b.from_node,"to":b.to_node,
                "enabled":b.enabled,"Q_from_to_W":q_ft,"Q_joule_W":q_joule_W,
                "Q_hot_end_W":self.current_lead_profiles.get(b.id,{}).get("q_hot_end_W"),
                "Q_cold_end_W":self.current_lead_profiles.get(b.id,{}).get("q_cold_end_W")})

        for ld in self.loads:
            if ld.enabled:
                gen_W[ld.node] += float(ld.power_W)

        cc = self.cryocooler
        stage_summary: Dict[str, float] = {}
        q1_req = net_in_W.get(cc.stage1_node, 0.0) + gen_W.get(cc.stage1_node, 0.0)
        q2_req = net_in_W.get(cc.stage2_node, 0.0) + gen_W.get(cc.stage2_node, 0.0)
        T1 = temps.get(cc.stage1_node)
        T2 = temps.get(cc.stage2_node)
        if T1 is not None:
            y1 = (T2 if cc.stage1.map_y_name == "other_stage_temperature" else q2_req) if cc.stage1.mode == "2d_map" else q1_req
            q1_cap, w1 = cc.stage1.capacity_W(T1, var2=float(y1))
            if w1: warnings.append(w1)
            cool_W[cc.stage1_node] = q1_cap
            stage_summary.update({"T1_K":T1,"Q1_load_W":q1_req,"Q1_cap_W":q1_cap,"Q1_margin_W":q1_cap-q1_req})
        if T2 is not None:
            y2 = (T1 if cc.stage2.map_y_name == "other_stage_temperature" else q1_req) if cc.stage2.mode == "2d_map" else q2_req
            q2_cap, w2 = cc.stage2.capacity_W(T2, var2=float(y2))
            if w2: warnings.append(w2)
            cool_W[cc.stage2_node] = q2_cap
            stage_summary.update({"T2_K":T2,"Q2_load_W":q2_req,"Q2_cap_W":q2_cap,"Q2_margin_W":q2_cap-q2_req})

        residuals_W: Dict[str, float] = {}
        for nid, node in self.nodes.items():
            if node.fixed_temp_K is not None:
                residuals_W[nid] = 0.0
            else:
                residuals_W[nid] = net_in_W[nid] + gen_W[nid] - cool_W[nid]

        return residuals_W, branch_rows, stage_summary, warnings

    @classmethod
    def build_default_demo(cls) -> "ThermalNetwork":
        net = cls(name="Demo_Conduction_Magnet", ambient_temp_K=293.15)
        net.add_node(ThermalNode(id="ambient", node_type="boundary", fixed_temp_K=293.15))
        net.add_node(ThermalNode(id="stage1", node_type="stage", material="OFHC_Cu_RRR100", mass_kg=2.5, target_temp_K=45.0))
        net.add_node(ThermalNode(id="shield", node_type="thermal_mass", material="Al6061_T6", mass_kg=8.0, target_temp_K=55.0))
        net.add_node(ThermalNode(id="stage2", node_type="stage", material="OFHC_Cu_RRR100", mass_kg=1.5, target_temp_K=4.5))
        net.add_node(ThermalNode(id="cold_mass", node_type="thermal_mass", material="OFHC_Cu_RRR100", mass_kg=35.0, target_temp_K=4.8))

        net.add_branch(
            ThermalBranch(
                id="mli_amb_shield",
                branch_type="mli",
                from_node="ambient",
                to_node="shield",
                params={"mode": "effective_k_literature", "area_m2": 1.8, "effective_k_WmK": 3.5e-5, "thickness_m": 0.03, "literature_preset": "ASHRAE evacuated MLI 12-28 layers/cm, 0.13 mPa"},
            )
        )
        net.add_branch(
            ThermalBranch(
                id="link_stage1_shield",
                branch_type="conduction",
                from_node="stage1",
                to_node="shield",
                params={"material": "OFHC_Cu_RRR100", "area_m2": 4e-4, "length_m": 0.15},
            )
        )
        net.add_branch(
            ThermalBranch(
                id="rad_shield_cm",
                branch_type="radiation",
                from_node="shield",
                to_node="cold_mass",
                params={"area_m2": 1.1, "emissivity_eff": 0.04, "view_factor": 1.0},
            )
        )
        net.add_branch(
            ThermalBranch(
                id="link_stage2_cm",
                branch_type="conduction",
                from_node="stage2",
                to_node="cold_mass",
                params={"material": "OFHC_Cu_RRR100", "area_m2": 6e-4, "length_m": 0.08},
            )
        )
        net.add_branch(
            ThermalBranch(
                id="strut_amb_stage1",
                branch_type="conduction",
                from_node="ambient",
                to_node="stage1",
                params={"material": "G10_Normal", "area_m2": 2e-4, "length_m": 0.25},
            )
        )
        net.add_branch(
            ThermalBranch(
                id="strut_s1_stage2",
                branch_type="conduction",
                from_node="stage1",
                to_node="stage2",
                params={"material": "G10_Normal", "area_m2": 1.5e-4, "length_m": 0.20},
            )
        )
        net.add_load(HeatLoad(id="ac_losses_cm", node="cold_mass", power_W=0.15, category="ac_loss", source="EM_estimate"))
        net.add_load(HeatLoad(id="inst_s1", node="stage1", power_W=1.2, category="instrumentation", source="harnesses"))
        return net
