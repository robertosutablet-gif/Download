# Riferimenti e campo di applicabilità dei modelli avanzati

## Current leads 1D
La forma differenziale implementata è quella di conduzione assiale con sorgente Joule distribuita:

`d/dx(k(T) A dT/dx) + I^2 rho_e(T)/A = 0`.

La formulazione è coerente con il modello di rete descritto nel documento `soluzione-reti-termiche.txt` fornito nel progetto. Per un sistema con intercetta al primo stadio, la lead va rappresentata con due rami distinti, ambiente→stage 1 e stage 1→stage 2. Il nodo comune costituisce l'intercetta. Il modello assume area costante e proprietà omogeneizzate lungo ciascun segmento.

## MLI Modified Lockheed

Hastings, L. J., Hedayat, A., Brown, T. M., *Analytical Modeling and Test Correlation of Variable Density Multilayer Insulation for Cryogenic Storage*, NASA/TM-2004-213175, May 2004, §4.2, Eq. (13), pp. 23–24.

La formula implementata è:

`q = 2.4e-4 f_Dacron(Tm) (N*)^2.63 (Th-Tc)/Ns`

`  + 4.944e-10 eps (Th^4.67-Tc^4.67)/Ns`

`  + 1.46e4 P_torr (Th^0.52-Tc^0.52)/Ns`

con `f_Dacron(T)=0.017+7e-6(800-T)+0.0228 ln(T)`, `N*` in layers/cm, `Ns` numero di schermi, `P` in torr e q in W/m². Nel programma la pressione è inserita in Pa e convertita internamente in torr.

I coefficienti modificati sono quelli del MHTB con Dacron netting e schermi DAM perforati. Il rapporto NASA riporta correlazione entro circa 8% al boundary caldo 305 K, ma scostamenti di circa 30% a 164 K; non è quindi una garanzia generale. La configurazione del blanket, i fori, la densità, lo spacer, il gas residuo e i danni d'installazione devono essere comparabili o ricalibrati.

Riferimento: https://ntrs.nasa.gov/citations/20040121015

## Contatti termici

Il ramo `CMY_generic` utilizza una forma CMY per contatti premuti:

`h_c = 1.25 k_s m / sigma * (P/H)^0.95`, `G_c = h_c A`.

`k_s` è la media armonica delle conducibilità dei due materiali alla temperatura media; `sigma` è la rugosità RMS combinata in m; `m` è la pendenza media delle asperità; `P` la pressione nominale e `H` la microdurezza della superficie più tenera. La formula è un modello ingegneristico di stima. Non è una correlazione criogenica calibrata per ogni coppia, finitura o intervallo termico.

Riferimenti sperimentali utili per limiti di applicabilità:
- Han, J. et al., *Investigation of thermal contact conductance of bare copper-copper and aluminum 1070-aluminum 1070 interfaces at low temperatures between 10 and 70 K*, Cryogenics 133 (2023), 103710, DOI 10.1016/j.cryogenics.2023.103710. Prove riportate per 6–13.5 MPa e finiture specifiche.
- Bi, D., Chen, H., Tian, Y., *Influences of temperature and contact pressure on thermal contact resistance at interfaces at cryogenic temperatures*, Cryogenics 52 (2012), 403–409, DOI 10.1016/j.cryogenics.2012.03.006. Confronta SS304–Cu e SS304–SS304 (oltre a SS304–AlN) tra 70–290 K e 0.2–0.7 MPa; evidenzia dipendenza da pressione e temperatura.
- Salmon, K., Nellis, G., Pfotenhauer, J., *Experimental characterization of cryogenic contact resistance*, Cryogenics (2022), 103587, DOI 10.1016/j.cryogenics.2022.103587.
- Cooper, M. G., Mikic, B. B., Yovanovich, M. M., *Thermal contact conductance*, International Journal of Heat and Mass Transfer 12 (1969), 279–300.

Non sono implementati coefficienti di fit specifici dei lavori citati quando i dati numerici completi (pressione, roughness, microhardness, materiali e temperature) non sono disponibili. Perciò il software non etichetta il risultato CMY come misura o correlazione sperimentale specifica della coppia.
