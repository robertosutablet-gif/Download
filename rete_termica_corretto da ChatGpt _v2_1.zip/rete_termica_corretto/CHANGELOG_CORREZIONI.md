# Registro interventi

## Correzioni incluse

1. Cryocooler: curva 1D inseribile da GUI; PCHIP con verifica dei limiti; estrapolazione tangente esplicita e segnalata; semantica unità della seconda coordinata delle mappe 2D; persistenza JSON delle curve e mappe.
2. Rete: ramo combinato conduzione-contatto in serie; rilevamento della configurazione parallela sospetta; MLI con modello a conducibilità efficace.
3. Current leads: nuovo ramo, input GUI di materiale, sezione, lunghezza e corrente; Joule da rho_e(T) e contributo dissipativo ai nodi.
4. Materiali: interpolazione di rho_e(T) resa disponibile.
5. Solver statico: limiti termici dei nodi cryocooler legati al dominio della curva; tolleranza richiesta applicata senza soglia minima nascosta.
6. Solver transitorio: nodi dinamici e algebrici trattati separatamente.
7. GUI: launcher `run_gui.py`, schermata current leads/contatti e inserimento manuale curve.

## Test eseguiti

- Compilazione Python di tutti i moduli: superata.
- Interpolazione curva 1D e controllo fuori dominio: superato.
- Calcolo current lead su materiale sintetico con k(T) e rho_e(T): superato.
- Calcolo ramo conduzione-contatto in serie: superato.
- Salvataggio/ricaricamento JSON curve 1D e mappa 2D: superato.
- Transitorio con nodo algebrico a massa nulla: superato.
- Solver statico demo: non converge, ma restituisce correttamente il mancato raggiungimento del bilancio invece di interrompersi con eccezione. Residuo massimo circa 1.57 W con le curve illustrative predefinite.

## Non eseguito

- GUI non avviata in questo ambiente perché PySide6 non è installato qui. La sintassi dei moduli GUI è stata compilata, ma il comportamento grafico va verificato su Windows dopo installazione requirements.
- Nessuna validazione sperimentale del sistema completo.


## Aggiornamento successivo – current leads 1D, MLI NASA e contatti multi-materiale

1. Sostituito il modello lumped delle current leads con BVP 1D distribuito per k(T), rho_e(T) e Joule I²R. Il bilancio nodale utilizza il flusso distinto ai due terminali; la differenza è la potenza Joule generata nel conduttore. Il profilo T(x) è memorizzato per la visualizzazione. Un'intercetta si realizza con nodi della rete e segmenti separati (ad es. ambiente→stage1 e stage1→stage2).
2. Sostituito il modello MLI parametrico non documentato con Modified Lockheed NASA/TM-2004-213175 Eq. (13): Dacron solid conduction, radiation e gas conduction. Pressione convertita Pa→torr. Inseriti emissività, numero strati, layer density, moltiplicatori e fattore di degradazione. Mantenute le modalità sperimentale CSV, k_eff e emissività.
3. Aggiunta stima CMY multi-materiale dipendente da k(T), pressione, rugosità RMS, microdurezza e slope delle asperità. I dati sperimentali pubblicati per alcune coppie sono indicati come intervalli di applicabilità, ma non sono trasformati in correlazioni numeriche in assenza dei coefficienti completi.
4. Aggiornata GUI per i parametri 1D, i parametri Modified Lockheed e le superfici/materiali dei contatti. Aggiunto comando per visualizzare T(x) e i flussi terminali/Joule.
5. Corretto il collegamento contatto CMY in serie con conduzione bulk.
