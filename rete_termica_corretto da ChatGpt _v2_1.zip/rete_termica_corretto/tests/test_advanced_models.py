import unittest
import numpy as np

from materials.library import MaterialCurve, MaterialLibrary
from physics.current_lead import solve_current_lead_1d
from physics.mli import MLIModel
from physics.contacts import cmy_contact_conductance
from core.network import ThermalNetwork, ThermalNode, ThermalBranch


class AdvancedModelTests(unittest.TestCase):
    def setUp(self):
        t = np.array([4.0, 50.0, 100.0, 300.0])
        self.constant = MaterialCurve(name="constant_test", T=t, k=np.full(4, 100.0),
                                      cp=np.ones(4), rho_e=np.full(4, 1e-8))

    def test_current_lead_joule_conservation(self):
        area, length, current = 1e-6, 0.5, 1.0
        result = solve_current_lead_1d(300.0, 50.0, area_m2=area, length_m=length,
                                       current_A=current, material=self.constant)
        expected = current**2 * 1e-8 * length / area
        self.assertAlmostEqual(result.joule_total_W, expected, places=8)
        self.assertAlmostEqual(result.q_cold_end_W-result.q_hot_end_W, expected, places=8)
        self.assertAlmostEqual(result.T_K[0], 300.0, places=8)
        self.assertAlmostEqual(result.T_K[-1], 50.0, places=8)

    def test_current_lead_zero_current_analytical(self):
        area, length = 1e-6, 0.5
        result = solve_current_lead_1d(300.0, 50.0, area_m2=area, length_m=length,
                                       current_A=0.0, material=self.constant)
        expected = 100.0 * area / length * 250.0
        self.assertAlmostEqual(result.q_hot_end_W, expected, places=8)
        self.assertAlmostEqual(result.q_cold_end_W, expected, places=8)

    def test_network_lead_profile_and_energy(self):
        lib = MaterialLibrary(); lib.materials["constant_test"] = self.constant
        net = ThermalNetwork(materials=lib)
        net.add_node(ThermalNode("hot", fixed_temp_K=300.0))
        net.add_node(ThermalNode("cold", fixed_temp_K=50.0))
        net.add_branch(ThermalBranch("lead", "current_lead_1d", "hot", "cold",
            {"material": "constant_test", "area_m2": 1e-6, "length_m": 0.5, "current_A": 1.0}))
        _, rows, _, _ = net.evaluate_balances({"hot": 300.0, "cold": 50.0})
        self.assertAlmostEqual(rows[0]["Q_cold_end_W"]-rows[0]["Q_hot_end_W"], rows[0]["Q_joule_W"], places=8)
        self.assertGreaterEqual(len(net.current_lead_profiles["lead"]["T_K"]), 41)

    def test_modified_lockheed_pressure_dependence(self):
        low = MLIModel(mode="modified_lockheed_nasa2004", layers=45, layer_density_per_cm=12,
                       residual_pressure_Pa=1e-4, emissivity_eff=0.04)
        high = MLIModel(mode="modified_lockheed_nasa2004", layers=45, layer_density_per_cm=12,
                        residual_pressure_Pa=1e-2, emissivity_eff=0.04)
        self.assertGreater(low._modified_lockheed_flux(305, 20), 0)
        self.assertGreater(high._modified_lockheed_flux(305, 20), low._modified_lockheed_flux(305, 20))

    def test_cmy_pressure_dependence(self):
        lib = MaterialLibrary()
        cu, al = lib.get("OFHC_Cu_RRR100"), lib.get("Al6061_T6")
        kwargs = dict(material_a=cu, material_b=al, temperature_K=20, area_m2=1e-4,
                      roughness_um=1.0, hardness_MPa=800.0)
        g_low = cmy_contact_conductance(pressure_MPa=0.5, **kwargs)
        g_high = cmy_contact_conductance(pressure_MPa=1.0, **kwargs)
        self.assertGreater(g_high, g_low)


if __name__ == "__main__":
    unittest.main()
