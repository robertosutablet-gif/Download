from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import numpy as np
import pandas as pd
from scipy.interpolate import LinearNDInterpolator
from scipy.optimize import brentq

SIGMA_SB = 5.670374419e-8
PA_PER_TORR = 133.322368421


@dataclass
class MLIModel:
    """MLI heat-flux models.

    ``modified_lockheed_nasa2004`` implements Eq. (13) of NASA/TM-2004-213175
    for the tested Dacron-net/perforated aluminized-shield configuration.
    Pressure input to this class is Pa and is converted to torr internally.
    ``degradation_factor`` multiplies the blanket heat leak to represent
    installation defects/penetrations only when the user supplies a justified
    factor; it is not a universal empirical constant.
    """
    mode: str = "modified_lockheed_nasa2004"
    area_m2: float = 1.0
    layers: int = 45
    layer_density_per_cm: float = 12.0
    residual_pressure_Pa: float = 1e-4
    emissivity_eff: float = 0.04
    parasitic_W: float = 0.0
    allow_extrapolation: bool = False
    exp_csv_path: Optional[str] = None
    effective_k_WmK: float = 3.5e-5
    thickness_m: float = 0.03
    degradation_factor: float = 1.0
    radiation_multiplier: float = 1.0
    solid_multiplier: float = 1.0
    gas_multiplier: float = 1.0
    gas_coefficient: float = 1.46e4  # Eq. (13), nitrogen, P in torr
    segments: Optional[list] = None  # [{layers: int, layer_density_per_cm: float}, ...]
    _interp: Optional[LinearNDInterpolator] = None

    def __post_init__(self) -> None:
        if self.mode == "experimental_csv" and self.exp_csv_path:
            self.load_experimental_csv(self.exp_csv_path)
        self._validate()

    def _validate(self):
        if self.area_m2 <= 0 or self.layers < 1 or self.layer_density_per_cm <= 0:
            raise ValueError("MLI: area, numero strati e densità devono essere positivi.")
        if self.residual_pressure_Pa < 0 or self.parasitic_W < 0:
            raise ValueError("MLI: pressione e carico parassita non possono essere negativi.")
        if not (0 < self.emissivity_eff <= 1):
            raise ValueError("MLI: emissività deve appartenere a (0,1].")
        if self.degradation_factor < 1 or min(self.radiation_multiplier, self.solid_multiplier, self.gas_multiplier) < 0:
            raise ValueError("MLI: fattore degradazione >=1 e moltiplicatori non negativi.")
        if self.segments:
            if any(int(seg.get("layers",0)) < 1 or float(seg.get("layer_density_per_cm",0)) <= 0 for seg in self.segments):
                raise ValueError("MLI: ogni segmento richiede layers>=1 e layer_density_per_cm>0.")
            if sum(int(seg["layers"]) for seg in self.segments) != int(self.layers):
                raise ValueError("MLI: la somma degli strati dei segmenti deve coincidere con il numero totale N_s.")

    def load_experimental_csv(self, filepath: str | Path) -> None:
        path = Path(filepath)
        df = pd.read_csv(path)
        cols = {c.lower().strip(): c for c in df.columns}
        for req in ("th_k", "tc_k", "q_flux_wm2"):
            if req not in cols:
                raise ValueError(f"CSV MLI '{path.name}' richiede colonna '{req}'.")
        th = pd.to_numeric(df[cols["th_k"]], errors="coerce").to_numpy(float)
        tc = pd.to_numeric(df[cols["tc_k"]], errors="coerce").to_numpy(float)
        q = pd.to_numeric(df[cols["q_flux_wm2"]], errors="coerce").to_numpy(float)
        mask = np.isfinite(th) & np.isfinite(tc) & np.isfinite(q)
        if np.count_nonzero(mask) < 3:
            raise ValueError("CSV MLI sperimentale: servono almeno tre righe valide.")
        self._interp = LinearNDInterpolator(np.column_stack([th[mask], tc[mask]]), q[mask])

    def _segment_flux(self, Th: float, Tc: float, layers: int, density: float) -> float:
        ns = max(int(layers), 1)
        nstar = float(density)
        tavg = 0.5 * (Th + Tc)
        k_dacron = 0.017 + 7.0e-6 * (800.0 - tavg) + 0.0228 * np.log(tavg)
        q_solid = (2.4e-4 * k_dacron * nstar**2.63 * (Th - Tc) / ns) * self.solid_multiplier
        q_rad = (4.944e-10 * self.emissivity_eff * (Th**4.67 - Tc**4.67) / ns) * self.radiation_multiplier
        p_torr = self.residual_pressure_Pa / PA_PER_TORR
        q_gas = (self.gas_coefficient * p_torr * (Th**0.52 - Tc**0.52) / ns) * self.gas_multiplier
        return float(max((q_solid + q_rad + q_gas) * self.degradation_factor, 0.0))

    def _modified_lockheed_flux(self, Th: float, Tc: float) -> float:
        if Th <= 0 or Tc <= 0:
            raise ValueError("MLI: temperature assolute devono essere >0 K.")
        segments = self.segments or [{"layers": self.layers, "layer_density_per_cm": self.layer_density_per_cm}]
        if len(segments) == 1:
            seg=segments[0]
            return self._segment_flux(Th,Tc,int(seg["layers"]),float(seg["layer_density_per_cm"]))
        # Segments are in series. Find the common heat flux for which the
        # intermediate interface temperatures connect Th to Tc.
        def final_temperature(qflux: float) -> float:
            t=Th
            for seg in segments:
                ns=int(seg["layers"]); nd=float(seg["layer_density_per_cm"])
                qmax=self._segment_flux(t,max(1e-6, min(Tc,t-1e-6)),ns,nd)
                if qflux <= 1e-14:
                    continue
                if qflux >= self._segment_flux(t,1e-6,ns,nd):
                    return -1.0
                t=brentq(lambda tn:self._segment_flux(t,tn,ns,nd)-qflux,1e-6,t-1e-8,xtol=1e-8)
            return t
        q_hi=min(self._segment_flux(Th,1e-6,int(seg["layers"]),float(seg["layer_density_per_cm"])) for seg in segments)
        qflux=brentq(lambda q:final_temperature(q)-Tc,0.0,q_hi*(1-1e-10),xtol=1e-10)
        return float(qflux)

    def heat_flow(self, T_a: float, T_b: float) -> float:
        if abs(T_a - T_b) < 1e-12:
            return 0.0
        sign = 1.0 if T_a > T_b else -1.0
        Th, Tc = max(T_a, T_b), min(T_a, T_b)
        if self.mode == "experimental_csv":
            if self._interp is None:
                raise ValueError("Modalità MLI sperimentale attiva ma tabella non caricata.")
            q_flux = float(self._interp(Th, Tc))
            if not np.isfinite(q_flux):
                raise ValueError(f"MLI sperimentale: (Th={Th:.2f}, Tc={Tc:.2f}) K fuori inviluppo CSV; non viene inventata un'estrapolazione.")
            q = q_flux * self.area_m2 * self.degradation_factor
        elif self.mode == "modified_lockheed_nasa2004":
            q = self._modified_lockheed_flux(Th, Tc) * self.area_m2
        elif self.mode == "effective_k_literature":
            if self.effective_k_WmK <= 0 or self.thickness_m <= 0:
                raise ValueError("MLI effective-k: k_eff e spessore devono essere positivi.")
            q = self.effective_k_WmK * self.area_m2 * (Th - Tc) / self.thickness_m * self.degradation_factor
        elif self.mode == "emissivity_eff":
            q = self.emissivity_eff * SIGMA_SB * self.area_m2 * (Th**4 - Tc**4) * self.degradation_factor
        else:
            raise ValueError(f"Modalità MLI non riconosciuta: {self.mode}")
        return sign * (q + self.parasitic_W)
