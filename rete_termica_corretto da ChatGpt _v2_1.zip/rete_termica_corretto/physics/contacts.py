from __future__ import annotations

import numpy as np

# The data-specific cryogenic literature does not support one universal h(P,T)
# value across all surface finishes. Generic CMY inputs must therefore be explicit.
_CONTACT_PRESETS = {
    "Cu-Cu_bare": {"reference": "Han et al., Cryogenics 133 (2023), 103710", "range": "10-70 K; 6-13.5 MPa; OFHC/Al1070 study; roughness-specific"},
    "Al1070-Al1070": {"reference": "Han et al., Cryogenics 133 (2023), 103710", "range": "10-70 K; 6-13.5 MPa; roughness-specific"},
    "SS304-Cu": {"reference": "Bi, Chen & Tian, Cryogenics 52 (2012), 403-409", "range": "70-290 K; 0.2-0.7 MPa"},
    "SS304-SS304": {"reference": "Bi, Chen & Tian, Cryogenics 52 (2012), 403-409", "range": "70-290 K; 0.2-0.7 MPa"},
    "CMY_generic": {"reference": "Cooper-Mikic-Yovanovich engineering correlation", "range": "estimate; requires measured roughness, hardness and asperity slope"},
}


def contact_heat_flow(T_a: float, T_b: float, conductance_WK: float | None = None,
                      resistance_KW: float | None = None) -> float:
    if conductance_WK is not None and conductance_WK > 0:
        g = float(conductance_WK)
    elif resistance_KW is not None and resistance_KW > 0:
        g = 1.0 / float(resistance_KW)
    else:
        raise ValueError("Specificare conductance_WK > 0 oppure resistance_KW > 0.")
    return g * (T_a - T_b)


def cmy_contact_conductance(*, material_a, material_b, temperature_K: float,
                            pressure_MPa: float, area_m2: float,
                            roughness_um: float, hardness_MPa: float,
                            asperity_slope: float = 0.1,
                            pressure_exponent: float = 0.95) -> float:
    """CMY-type estimate of pressed contact conductance [W/K].

    h_c = 1.25*k_s*m/sigma*(P/H)^0.95; G=h_c*A.
    sigma is combined RMS roughness (m); k_s is harmonic mean of the
    two bulk conductivities. H is the softer-surface microhardness.
    This is an engineering estimate, not a fitted cryogenic correlation.
    """
    if pressure_MPa <= 0 or area_m2 <= 0 or roughness_um <= 0 or hardness_MPa <= 0 or asperity_slope <= 0:
        raise ValueError("CMY: pressione, area, rugosità, durezza e pendenza asperità devono essere positive.")
    ka = float(np.asarray(material_a.k_at(temperature_K)))
    kb = float(np.asarray(material_b.k_at(temperature_K)))
    if ka <= 0 or kb <= 0:
        raise ValueError("CMY: k(T) dei due materiali deve essere positiva.")
    ks = 2.0 * ka * kb / (ka + kb)
    sigma_m = roughness_um * 1e-6
    ratio = (pressure_MPa / hardness_MPa) ** float(pressure_exponent)
    h = 1.25 * ks * asperity_slope / sigma_m * ratio
    return float(h * area_m2)


def preset_contact_conductance(preset: str, pressure_MPa: float, area_m2: float,
                               pressure_exponent: float = 0.8) -> float:
    """Legacy compatibility only: legacy Cu-Cu nominal value is not universal."""
    if preset not in _CONTACT_PRESETS:
        raise ValueError(f"Preset contatto sconosciuto: {preset}")
    if pressure_MPa <= 0 or area_m2 <= 0:
        raise ValueError("Pressione e area di contatto devono essere positive.")
    if preset != "Cu-Cu_bare":
        raise ValueError(f"Per {preset} usare CMY_generic con proprietà superficiali esplicite; non esiste un h universale.")
    # Kept for backwards compatibility; clearly flagged as rough nominal estimate.
    h_ref, p_ref = 800.0, 3.8
    return h_ref * (pressure_MPa / p_ref) ** float(pressure_exponent) * area_m2


def contact_preset_info():
    return {k: dict(v) for k, v in _CONTACT_PRESETS.items()}
