from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from scipy.integrate import solve_bvp


@dataclass
class CurrentLeadResult:
    x_m: np.ndarray
    T_K: np.ndarray
    q_hot_end_W: float       # heat entering the lead from node at x=0
    q_cold_end_W: float      # heat leaving the lead into node at x=L
    joule_total_W: float
    success: bool
    message: str


def solve_current_lead_1d(T_hot: float, T_cold: float, *, area_m2: float,
                          length_m: float, current_A: float, material,
                          n_points: int = 41, tol: float = 1e-5,
                          max_nodes: int = 2000) -> CurrentLeadResult:
    """Solve d/dx(k(T) A dT/dx) + I² rho_e(T)/A = 0 by collocation.

    Coordinate x runs from ``from_node`` (x=0) to ``to_node`` (x=L).
    q(x)=-k(T) A dT/dx is positive in the +x direction. Consequently
    q_hot_end is heat extracted from the first node and q_cold_end is
    heat delivered to the second node. Their difference is total Joule heat.
    The two endpoints can be two successive thermal-intercept nodes, e.g.
    ambient->stage1 and stage1->stage2.
    """
    if area_m2 <= 0 or length_m <= 0 or current_A < 0:
        raise ValueError("Current lead 1D: area/lunghezza positive e corrente non negativa.")
    if material.rho_e is None:
        raise ValueError(f"Materiale '{material.name}' privo di rho_e(T).")
    if material.k is None:
        raise ValueError(f"Materiale '{material.name}' privo di k(T).")
    if min(T_hot, T_cold) < material.t_min or max(T_hot, T_cold) > material.t_max:
        if not material.allow_extrapolation:
            raise ValueError(f"Current lead '{material.name}': temperature [{min(T_hot,T_cold):.3f}, {max(T_hot,T_cold):.3f}] K fuori dominio [{material.t_min:.3f}, {material.t_max:.3f}] K.")

    x = np.linspace(0.0, length_m, max(9, int(n_points)))
    T0 = np.linspace(T_hot, T_cold, x.size)
    # y[0]=T; y[1]=q=-k A dT/dx
    q0 = area_m2 / length_m * material.integrate_k(min(T_hot, T_cold), max(T_hot, T_cold))
    if T_hot < T_cold:
        q0 = -q0
    y0 = np.vstack([T0, np.full_like(x, q0)])

    def ode(xv, y):
        # During Newton/collocation iterations trial temperatures can overshoot
        # the physical interval; evaluate properties at the nearest tabulated
        # endpoint, then validate the converged profile below.
        temp = np.clip(y[0], material.t_min, material.t_max)
        kval = np.asarray(material.k_at(temp), dtype=float)
        rho = np.asarray(material.rho_e_at(temp), dtype=float)
        if np.any(~np.isfinite(kval)) or np.any(kval <= 0) or np.any(~np.isfinite(rho)) or np.any(rho < 0):
            raise ValueError("Proprietà k(T) o rho_e(T) non fisiche nella current lead.")
        dTdx = -y[1] / (kval * area_m2)
        dqdx = current_A**2 * rho / area_m2
        return np.vstack([dTdx, dqdx])

    def bc(ya, yb):
        return np.array([ya[0] - T_hot, yb[0] - T_cold])

    sol = solve_bvp(ode, bc, x, y0, tol=tol, max_nodes=max_nodes, verbose=0)
    if not sol.success:
        raise RuntimeError(f"Solver current lead 1D non convergente: {sol.message}")
    xf = np.linspace(0.0, length_m, max(41, int(n_points)))
    yf = sol.sol(xf)
    Tf, qf = yf[0], yf[1]
    if np.min(Tf) < material.t_min-1e-6 or np.max(Tf) > material.t_max+1e-6:
        raise ValueError(f"Profilo current lead fuori dominio proprietà del materiale [{material.t_min:.3f}, {material.t_max:.3f}] K.")
    q_hot = float(qf[0])
    q_cold = float(qf[-1])
    p_joule = float(q_cold - q_hot)
    # Small negative values can arise from collocation roundoff only.
    if p_joule < -max(1e-8, 1e-6 * max(abs(q_hot), abs(q_cold), 1.0)):
        raise RuntimeError(f"Bilancio lead non fisico: P_Joule={p_joule:.6g} W.")
    p_joule = max(0.0, p_joule)
    return CurrentLeadResult(xf, Tf, q_hot, q_cold, p_joule, bool(sol.success), str(sol.message))


# Backward-compatible wrapper retained for scripts using the previous reduced model.
def current_lead_terms(Ta: float, Tb: float, *, area_m2: float, length_m: float,
                       current_A: float, material, n_points: int = 31):
    result = solve_current_lead_1d(Ta, Tb, area_m2=area_m2, length_m=length_m,
                                   current_A=current_A, material=material, n_points=n_points)
    return result.q_hot_end_W, result.joule_total_W
