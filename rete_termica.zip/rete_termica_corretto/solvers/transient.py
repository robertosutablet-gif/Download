from __future__ import annotations
from dataclasses import dataclass
from typing import Dict
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from core.network import ThermalNetwork

@dataclass
class TransientResult:
    success: bool
    message: str
    time_s: np.ndarray
    temperatures_K: Dict[str, np.ndarray]

def simulate_cooldown(network: ThermalNetwork, initial_temps_K: Dict[str,float], t_end_s:float=3600., n_points:int=200, method:str="BDF") -> TransientResult:
    dyn=[n for n in network.nodes.values() if n.fixed_temp_K is None and n.mass_kg>0]
    alg=[n for n in network.nodes.values() if n.fixed_temp_K is None and n.mass_kg<=0]
    if not dyn: raise ValueError("Nessun nodo dinamico con mass_kg > 0.")
    base={nid:(float(n.fixed_temp_K) if n.fixed_temp_K is not None else float(initial_temps_K.get(nid,n.target_temp_K or 293.15))) for nid,n in network.nodes.items()}
    for n in dyn:
        if not n.material: raise ValueError(f"Nodo dinamico '{n.id}' privo di materiale per cp(T).")
        if n.material not in network.materials.materials: raise ValueError(f"Materiale '{n.material}' non disponibile.")
    y0=np.array([base[n.id] for n in dyn],float)
    z0=np.array([base[n.id] for n in alg],float)
    def complete_temps(y,z_guess):
        temps=dict(base)
        for i,n in enumerate(dyn): temps[n.id]=float(y[i])
        if alg:
            def algfun(z):
                for j,n in enumerate(alg): temps[n.id]=float(z[j])
                rr,_,_,_=network.evaluate_balances(temps)
                return np.array([rr[n.id] for n in alg],float)
            zsol=least_squares(algfun,z_guess,bounds=(np.full(len(alg),1.0),np.full(len(alg),400.0)),xtol=1e-9,ftol=1e-9,gtol=1e-9,max_nfev=100)
            if not zsol.success and np.max(np.abs(algfun(zsol.x)))>1e-3:
                raise RuntimeError("Risoluzione dei nodi algebrici fallita nel transitorio: "+str(zsol.message))
            for j,n in enumerate(alg): temps[n.id]=float(zsol.x[j])
            return temps,zsol.x
        return temps,z_guess
    last_z=z0.copy()
    def rhs(_t,y):
        nonlocal last_z
        temps,last_z=complete_temps(y,last_z)
        res,_,_,_=network.evaluate_balances(temps)
        out=np.zeros_like(y)
        for i,n in enumerate(dyn):
            cp=float(network.materials.get(n.material).cp_at(temps[n.id]))
            if not np.isfinite(cp) or cp<=0: raise ValueError(f"cp non valido nel nodo {n.id}.")
            out[i]=res[n.id]/(n.mass_kg*cp)
        return out
    sol=solve_ivp(rhs,(0.,t_end_s),y0,method=method,t_eval=np.linspace(0.,t_end_s,n_points),rtol=1e-5,atol=1e-7)
    out={nid:np.full_like(sol.t,base[nid],dtype=float) for nid in network.nodes}
    for i,n in enumerate(dyn): out[n.id]=sol.y[i]
    # Ricostruzione coerente dei nodi algebrici a ogni istante campionato.
    z=z0.copy()
    for k in range(len(sol.t)):
        yk=sol.y[:,k]; temps,z=complete_temps(yk,z)
        for n in alg: out[n.id][k]=temps[n.id]
    return TransientResult(bool(sol.success),str(sol.message),sol.t,out)
