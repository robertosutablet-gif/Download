from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional
import numpy as np
from scipy.optimize import least_squares

from core.network import ThermalNetwork


@dataclass
class StaticSolution:
    converged: bool
    message: str
    temperatures_K: Dict[str, float]
    residuals_W: Dict[str, float]
    max_abs_residual_W: float
    global_energy_imbalance_W: float
    branch_results: List[Dict]
    stage_summary: Dict[str, float]
    warnings: List[str]


def solve_static(
    network: ThermalNetwork,
    initial_temps_K: Optional[Dict[str, float]] = None,
    t_bounds_K: tuple[float, float] = (3.5, 300.0),
    tol_W: float = 1e-5,
) -> StaticSolution:
    issues = network.validate_graph()
    if issues:
        raise ValueError("Rete non valida:\n- " + "\n- ".join(issues))

    unknowns = network.unknown_nodes()
    base_temps: Dict[str, float] = {}
    for nid, n in network.nodes.items():
        if n.fixed_temp_K is not None:
            base_temps[nid] = float(n.fixed_temp_K)
        elif initial_temps_K and nid in initial_temps_K:
            base_temps[nid] = float(initial_temps_K[nid])
        else:
            base_temps[nid] = float(np.clip(n.target_temp_K or 50.0, t_bounds_K[0] + 0.1, t_bounds_K[1] - 0.1))

    if not unknowns:
        res_W, branches, stage, warn = network.evaluate_balances(base_temps)
        return StaticSolution(True, "Nessuna incognita termica: rete interamente vincolata.", base_temps,
                              res_W, 0.0, 0.0, branches, stage, warn)

    x0 = np.array([base_temps[n.id] for n in unknowns], dtype=float)
    lb = np.full_like(x0, t_bounds_K[0])
    ub = np.full_like(x0, t_bounds_K[1])
    # Il solver non deve interrogare le curve del cryocooler fuori dal loro dominio.
    cc=network.cryocooler
    for i,node in enumerate(unknowns):
        model = cc.stage1 if node.id == cc.stage1_node else (cc.stage2 if node.id == cc.stage2_node else None)
        if model is not None and model.mode == "1d_curve" and model.T_curve is not None:
            lb[i]=max(lb[i],float(model.T_curve[0])); ub[i]=min(ub[i],float(model.T_curve[-1]))
        elif model is not None and model.mode == "2d_map" and model.map_x is not None:
            lb[i]=max(lb[i],float(np.min(model.map_x))); ub[i]=min(ub[i],float(np.max(model.map_x)))
    if np.any(lb>=ub): raise ValueError("Intervallo di temperatura vuoto per uno o più nodi.")
    # Punto iniziale strettamente interno ai limiti effettivi.
    x0=np.minimum(np.maximum(x0,lb+1e-8),ub-1e-8)

    scale_T = 100.0
    last_eval = {"res": {}, "branches": [], "stage": {}, "warn": []}

    def fun_scaled(x_scaled: np.ndarray) -> np.ndarray:
        x_K = x_scaled * scale_T
        temps = dict(base_temps)
        for idx, node in enumerate(unknowns):
            temps[node.id] = float(x_K[idx])
        res_W, branches, stage, warn = network.evaluate_balances(temps)
        last_eval["res"] = res_W
        last_eval["branches"] = branches
        last_eval["stage"] = stage
        last_eval["warn"] = warn
        return np.array([res_W[n.id] for n in unknowns], dtype=float)

    sol = least_squares(
        fun_scaled,
        x0 / scale_T,
        bounds=(lb / scale_T, ub / scale_T),
        ftol=1e-11,
        xtol=1e-11,
        gtol=1e-11,
        max_nfev=400,
    )

    final_temps = dict(base_temps)
    for idx, node in enumerate(unknowns):
        final_temps[node.id] = float(sol.x[idx] * scale_T)

    res_W, branches, stage, warn = network.evaluate_balances(final_temps)
    all_warnings = list(dict.fromkeys(warn + last_eval["warn"]))

    for n in unknowns:
        mat_name = n.material
        if mat_name and mat_name in network.materials.materials:
            all_warnings.extend(network.materials.get(mat_name).check_bounds(final_temps[n.id], label=n.id))

    abs_res = [abs(res_W[n.id]) for n in unknowns]
    max_res = max(abs_res) if abs_res else 0.0
    # I nodi a temperatura imposta hanno residuo artificiosamente nullo nel
    # sistema delle incognite: non usare la somma di tali residui come bilancio globale.
    # La somma dei residui dei soli nodi liberi misura la chiusura numerica del solve.
    global_imbalance = float(sum(res_W[n.id] for n in unknowns))
    converged = bool(sol.success and max_res <= tol_W)

    return StaticSolution(
        converged=converged,
        message=sol.message,
        temperatures_K=final_temps,
        residuals_W=res_W,
        max_abs_residual_W=max_res,
        global_energy_imbalance_W=global_imbalance,
        branch_results=branches,
        stage_summary=stage,
        warnings=all_warnings,
    )
