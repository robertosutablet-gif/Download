from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple
import numpy as np
from scipy.optimize import minimize

from core.network import ThermalNetwork
from solvers.static import solve_static


@dataclass
class SizingResult:
    success: bool
    message: str
    optimal_area_m2: float
    optimal_length_m: float
    objective_value: float
    target_node_temp_K: float


def size_conduction_branch(
    network: ThermalNetwork,
    branch_id: str,
    objective_node_id: str,
    area_bounds_m2: Tuple[float, float] = (1e-6, 5e-3),
    length_bounds_m: Tuple[float, float] = (0.02, 1.5),
    weight_temp: float = 1.0,
    weight_power: float = 0.0,
) -> SizingResult:
    target_branch = next((b for b in network.branches if b.id == branch_id), None)
    if target_branch is None:
        raise KeyError(f"Ramo '{branch_id}' non trovato.")
    if target_branch.branch_type != "conduction":
        raise ValueError(f"Il ramo '{branch_id}' non è di tipo 'conduction'.")

    orig_area = float(target_branch.params["area_m2"])
    orig_len = float(target_branch.params["length_m"])

    def obj(x: np.ndarray) -> float:
        a_val, l_val = float(x[0] * 1e-4), float(x[1])
        target_branch.params["area_m2"] = a_val
        target_branch.params["length_m"] = l_val
        sol = solve_static(network)
        if not sol.converged:
            return 1e9
        t_node = sol.temperatures_K[objective_node_id]
        q_branch = abs(next((r["Q_from_to_W"] for r in sol.branch_results if r["id"] == branch_id), 0.0))
        return weight_temp * t_node + weight_power * q_branch

    x0 = np.array([orig_area * 1e4, orig_len], dtype=float)
    bounds = [(area_bounds_m2[0] * 1e4, area_bounds_m2[1] * 1e4), length_bounds_m]

    res = minimize(obj, x0, method="L-BFGS-B", bounds=bounds)
    opt_a = float(res.x[0] * 1e-4)
    opt_l = float(res.x[1])
    target_branch.params["area_m2"] = opt_a
    target_branch.params["length_m"] = opt_l
    final_sol = solve_static(network)

    return SizingResult(
        success=bool(res.success and final_sol.converged),
        message=str(res.message),
        optimal_area_m2=opt_a,
        optimal_length_m=opt_l,
        objective_value=float(res.fun),
        target_node_temp_K=float(final_sol.temperatures_K[objective_node_id]),
    )
