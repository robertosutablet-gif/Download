from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional
import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator


@dataclass
class MaterialCurve:
    name: str
    source: str = "User/CSV"
    version: str = "1.0"
    interp_mode: str = "pchip"  # "pchip" | "linear"
    allow_extrapolation: bool = False
    T: np.ndarray = field(default_factory=lambda: np.array([]))
    k: Optional[np.ndarray] = None
    cp: Optional[np.ndarray] = None
    rho_e: Optional[np.ndarray] = None
    rho_m: Optional[np.ndarray] = None
    emissivity: Optional[np.ndarray] = None

    _k_eval: object = field(default=None, repr=False)
    _k_int_interp: Optional[PchipInterpolator] = field(default=None, repr=False)
    _cp_eval: object = field(default=None, repr=False)
    _eps_eval: object = field(default=None, repr=False)
    _rho_e_eval: object = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self._validate_and_build()

    @property
    def t_min(self) -> float:
        return float(self.T[0])

    @property
    def t_max(self) -> float:
        return float(self.T[-1])

    def check_bounds(self, T_val: float | np.ndarray, label: str = "T") -> List[str]:
        warnings: List[str] = []
        if self.allow_extrapolation:
            return warnings
        arr = np.asarray(T_val, dtype=float)
        if np.any(arr < self.t_min - 1e-9) or np.any(arr > self.t_max + 1e-9):
            warnings.append(
                f"Materiale '{self.name}' ({label}): T fuori intervallo [{self.t_min:.2f}, {self.t_max:.2f}] K "
                f"(valori [{float(np.min(arr)):.2f}, {float(np.max(arr)):.2f}] K) - estrapolazione bloccata."
            )
        return warnings

    def _make_1d_func(self, y: Optional[np.ndarray], positive: bool = False):
        if y is None:
            return None
        valid = ~np.isnan(y)
        t_v = self.T[valid]
        y_v = y[valid]
        if len(t_v) < 2:
            raise ValueError(f"Materiale '{self.name}': servono almeno 2 punti validi.")
        if positive and np.any(y_v <= 0.0):
            raise ValueError(f"Materiale '{self.name}': trovati valori <= 0 non fisici.")

        if self.interp_mode == "linear":
            def eval_lin(x):
                x_arr = np.asarray(x, dtype=float)
                if not self.allow_extrapolation and (
                    np.any(x_arr < t_v[0] - 1e-9) or np.any(x_arr > t_v[-1] + 1e-9)
                ):
                    raise ValueError(
                        f"Materiale '{self.name}': fuori dominio [{t_v[0]}, {t_v[-1]}] K."
                    )
                return np.interp(x_arr, t_v, y_v)
            return eval_lin

        pchip = PchipInterpolator(t_v, y_v, extrapolate=self.allow_extrapolation)

        def eval_pchip(x):
            x_arr = np.asarray(x, dtype=float)
            if not self.allow_extrapolation and (
                np.any(x_arr < t_v[0] - 1e-9) or np.any(x_arr > t_v[-1] + 1e-9)
            ):
                raise ValueError(
                    f"Materiale '{self.name}': fuori dominio [{t_v[0]}, {t_v[-1]}] K."
                )
            return pchip(x_arr)

        return eval_pchip

    def _validate_and_build(self) -> None:
        self.T = np.asarray(self.T, dtype=float)
        if self.T.ndim != 1 or len(self.T) < 2:
            raise ValueError(f"Materiale '{self.name}': colonna temperatura non valida.")
        if np.any(np.isnan(self.T)) or np.any(self.T <= 0.0):
            raise ValueError(f"Materiale '{self.name}': temperature devono essere > 0 K senza NaN.")
        if np.any(np.diff(self.T) <= 0.0):
            raise ValueError(f"Materiale '{self.name}': temperatura T deve essere strettamente crescente.")

        for prop_name, arr in [
            ("k", self.k),
            ("cp", self.cp),
            ("rho_e", self.rho_e),
            ("rho_m", self.rho_m),
            ("emissivity", self.emissivity),
        ]:
            if arr is not None:
                a = np.asarray(arr, dtype=float)
                if len(a) != len(self.T):
                    raise ValueError(f"Materiale '{self.name}': lunghezza incoerente per '{prop_name}'.")
                if prop_name == "emissivity":
                    non_nan = a[~np.isnan(a)]
                    if np.any((non_nan < 0.0) | (non_nan > 1.0)):
                        raise ValueError(f"Materiale '{self.name}': emissività fuori [0, 1].")
                else:
                    non_nan = a[~np.isnan(a)]
                    if np.any(non_nan < 0.0):
                        raise ValueError(f"Materiale '{self.name}': valore negativo in '{prop_name}'.")

        self._k_eval = self._make_1d_func(self.k, positive=True)
        self._cp_eval = self._make_1d_func(self.cp, positive=True)
        self._eps_eval = self._make_1d_func(self.emissivity, positive=False)
        self._rho_e_eval = self._make_1d_func(self.rho_e, positive=False)

        if self._k_eval is not None:
            t_grid = np.linspace(self.t_min, self.t_max, 2001)
            k_grid = np.asarray(self._k_eval(t_grid), dtype=float)
            dt = np.diff(t_grid)
            cum_int = np.concatenate([[0.0], np.cumsum(0.5 * (k_grid[:-1] + k_grid[1:]) * dt)])
            self._k_int_interp = PchipInterpolator(t_grid, cum_int, extrapolate=self.allow_extrapolation)

    def k_at(self, T: float | np.ndarray) -> np.ndarray:
        if self._k_eval is None:
            raise ValueError(f"Materiale '{self.name}' privo di conduttività termica k(T).")
        return np.asarray(self._k_eval(T), dtype=float)

    def cp_at(self, T: float | np.ndarray) -> np.ndarray:
        if self._cp_eval is None:
            raise ValueError(f"Materiale '{self.name}' privo di calore specifico cp(T).")
        return np.asarray(self._cp_eval(T), dtype=float)

    def rho_e_at(self, T: float | np.ndarray) -> np.ndarray:
        if self._rho_e_eval is None:
            raise ValueError(f"Materiale '{self.name}' privo di resistività elettrica rho_e(T).")
        return np.asarray(self._rho_e_eval(T), dtype=float)

    def eps_at(self, T: float | np.ndarray) -> np.ndarray:
        if self._eps_eval is None:
            raise ValueError(f"Materiale '{self.name}' privo di emissività eps(T).")
        return np.asarray(self._eps_eval(T), dtype=float)

    def integrate_k(self, T_cold: float, T_hot: float) -> float:
        if self._k_int_interp is None:
            raise ValueError(f"Materiale '{self.name}' privo di k(T) per l'integrazione.")
        if not self.allow_extrapolation:
            for val in (T_cold, T_hot):
                if val < self.t_min - 1e-9 or val > self.t_max + 1e-9:
                    raise ValueError(
                        f"Materiale '{self.name}': T={val:.2f} K fuori dominio [{self.t_min:.2f}, {self.t_max:.2f}] K."
                    )
        return float(self._k_int_interp(T_hot) - self._k_int_interp(T_cold))


class MaterialLibrary:
    def __init__(self) -> None:
        self.materials: Dict[str, MaterialCurve] = {}
        self._load_builtin_defaults()

    def _load_builtin_defaults(self) -> None:
        T = np.array([3.5, 4.0, 10.0, 20.0, 40.0, 77.0, 150.0, 300.0])
        self.materials["OFHC_Cu_RRR100"] = MaterialCurve(
            name="OFHC_Cu_RRR100",
            source="Built-in reference curve (verify with NIST/data)",
            version="1.0",
            T=T,
            k=np.array([1050.0, 1200.0, 1950.0, 1650.0, 820.0, 520.0, 415.0, 398.0]),
            cp=np.array([0.05, 0.08, 0.35, 1.8, 12.5, 62.0, 260.0, 385.0]),
            rho_m=np.full_like(T, 8940.0),
        )
        self.materials["Al6061_T6"] = MaterialCurve(
            name="Al6061_T6",
            source="Built-in reference curve (verify with NIST/data)",
            version="1.0",
            T=T,
            k=np.array([7.5, 8.5, 20.0, 38.0, 72.0, 118.0, 152.0, 167.0]),
            cp=np.array([0.08, 0.12, 0.45, 2.5, 18.0, 88.0, 520.0, 896.0]),
            rho_m=np.full_like(T, 2700.0),
            emissivity=np.array([0.02, 0.02, 0.02, 0.025, 0.03, 0.035, 0.045, 0.06]),
        )
        self.materials["G10_Normal"] = MaterialCurve(
            name="G10_Normal",
            source="Built-in reference curve (verify with NIST/data)",
            version="1.0",
            T=T,
            k=np.array([0.07, 0.08, 0.12, 0.18, 0.26, 0.36, 0.45, 0.55]),
            cp=np.array([0.9, 1.2, 4.5, 16.0, 55.0, 145.0, 410.0, 820.0]),
            rho_m=np.full_like(T, 1800.0),
        )
        self.materials["SS304"] = MaterialCurve(
            name="SS304",
            source="Built-in reference curve (verify with NIST/data)",
            version="1.0",
            T=T,
            k=np.array([0.21, 0.25, 0.65, 1.5, 3.6, 7.8, 12.2, 15.0]),
            cp=np.array([0.25, 0.35, 1.4, 6.5, 28.0, 95.0, 310.0, 477.0]),
            rho_m=np.full_like(T, 8000.0),
        )
        # Lega di titanio Ti-6Al-4V (Grade 5 / UNS R56400)
        self.materials["Ti6Al4V"] = MaterialCurve(
            name="Ti6Al4V",
            source="Built-in reference curve (Ti-6Al-4V Grade 5; verify with NIST/Cryogenics data)",
            version="1.0",
            T=T,
            k=np.array([0.48, 0.56, 1.25, 2.25, 3.45, 4.55, 5.75, 6.75]),
            cp=np.array([0.22, 0.32, 1.35, 6.20, 29.5, 112.0, 355.0, 526.0]),
            rho_m=np.full_like(T, 4430.0),
        )
        # Superlega Inconel 718 (UNS N07718)
        self.materials["Inconel718"] = MaterialCurve(
            name="Inconel718",
            source="Built-in reference curve (Inconel 718 UNS N07718; verify with NIST/data)",
            version="1.0",
            T=T,
            k=np.array([0.42, 0.49, 1.05, 2.05, 3.65, 5.95, 8.65, 11.4]),
            cp=np.array([0.19, 0.27, 1.05, 5.10, 23.5, 90.0, 310.0, 435.0]),
            rho_m=np.full_like(T, 8190.0),
        )
        # Superlega Inconel 725 (UNS N07725)
        self.materials["Inconel725"] = MaterialCurve(
            name="Inconel725",
            source="Built-in reference curve (Inconel 725 UNS N07725; verify with NIST/data)",
            version="1.0",
            T=T,
            k=np.array([0.38, 0.44, 0.96, 1.90, 3.40, 5.60, 8.20, 10.8]),
            cp=np.array([0.18, 0.25, 0.98, 4.85, 22.0, 86.0, 298.0, 420.0]),
            rho_m=np.full_like(T, 8310.0),
        )
        # Ottone (Brass C26000)
        self.materials["Brass"] = MaterialCurve(
            name="Brass",
            source="Built-in reference curve (Cartridge Brass C26000; verify with NIST/data)",
            version="1.0",
            T=T,
            k=np.array([1.8, 2.2, 6.5, 14.0, 28.0, 52.0, 88.0, 115.0]),
            cp=np.array([0.12, 0.18, 0.85, 4.2, 19.0, 78.0, 295.0, 377.0]),
            rho_m=np.full_like(T, 8530.0),
        )
        # Conduttore composito superconduttore REBCO
        self.materials["REBCO"] = MaterialCurve(
            name="REBCO",
            source="Built-in reference composite curve (REBCO coated conductor; verify with data)",
            version="1.0",
            T=T,
            k=np.array([180.0, 210.0, 320.0, 280.0, 160.0, 95.0, 68.0, 55.0]),
            cp=np.array([0.15, 0.22, 1.1, 5.5, 24.0, 85.0, 280.0, 410.0]),
            rho_m=np.full_like(T, 8700.0),
        )

    def load_from_file(
        self,
        filepath: str | Path,
        name: Optional[str] = None,
        col_map: Optional[Dict[str, str]] = None,
        source: Optional[str] = None,
        version: str = "1.0",
        interp_mode: str = "pchip",
        allow_extrapolation: bool = False,
        sheet_name: Optional[str] = None,
    ) -> MaterialCurve:
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"File materiale non trovato: {path}")

        if path.suffix.lower() in {".xlsx", ".xls"}:
            df = pd.read_excel(path, sheet_name=sheet_name if sheet_name else 0)
        else:
            df = pd.read_csv(path)

        df.columns = [str(c).strip() for c in df.columns]
        mapping = {
            "T": "T",
            "k": "k",
            "cp": "cp",
            "rho_e": "rho_e",
            "rho_m": "rho_m",
            "emissivity": "emissivity",
        }
        if col_map:
            mapping.update({k: v for k, v in col_map.items() if v})

        lower_cols = {c.lower(): c for c in df.columns}
        resolved: Dict[str, str] = {}
        for target, given in mapping.items():
            if given in df.columns:
                resolved[target] = given
            elif given.lower() in lower_cols:
                resolved[target] = lower_cols[given.lower()]

        if "T" not in resolved:
            raise ValueError(f"Colonna temperatura 'T' non trovata in {path.name}. Colonne: {list(df.columns)}")

        T_vals = pd.to_numeric(df[resolved["T"]], errors="coerce").to_numpy(dtype=float)

        def opt_col(key: str) -> Optional[np.ndarray]:
            if key not in resolved:
                return None
            return pd.to_numeric(df[resolved[key]], errors="coerce").to_numpy(dtype=float)

        mat_name = name or path.stem
        mat = MaterialCurve(
            name=mat_name,
            source=source or f"File: {path.name}",
            version=version,
            interp_mode=interp_mode,
            allow_extrapolation=allow_extrapolation,
            T=T_vals,
            k=opt_col("k"),
            cp=opt_col("cp"),
            rho_e=opt_col("rho_e"),
            rho_m=opt_col("rho_m"),
            emissivity=opt_col("emissivity"),
        )
        self.materials[mat_name] = mat
        return mat

    def get(self, name: str) -> MaterialCurve:
        if name not in self.materials:
            raise KeyError(f"Materiale '{name}' non presente in libreria.")
        return self.materials[name]

    def list_names(self) -> List[str]:
        return list(self.materials.keys())
