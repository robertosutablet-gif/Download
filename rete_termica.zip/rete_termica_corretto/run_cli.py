from __future__ import annotations

from pathlib import Path as _Path
import sys as _sys
_ROOT_DIR = str(_Path(__file__).resolve().parent)
if _ROOT_DIR not in _sys.path:
    _sys.path.insert(0, _ROOT_DIR)

import argparse
from core.network import ThermalNetwork
import importlib.util as _ilu
from pathlib import Path as _Path
_pio_path = str(_Path(__file__).resolve().parent / 'io' / 'project_io.py')
_pio_spec = _ilu.spec_from_file_location('project_io', _pio_path)
_pio_mod = _ilu.module_from_spec(_pio_spec)
_pio_spec.loader.exec_module(_pio_mod)
load_project_json = _pio_mod.load_project_json
export_static_results_csv = _pio_mod.export_static_results_csv
from solvers.static import solve_static


def main() -> None:
    parser = argparse.ArgumentParser(description="Solutore rete termica magneti superconduttori")
    parser.add_argument("--project", type=str, default="", help="Percorso file JSON progetto")
    parser.add_argument("--export-csv", type=str, default="", help="Cartella export risultati CSV")
    args = parser.parse_args()

    net = ThermalNetwork.build_default_demo()
    if args.project:
        load_project_json(args.project, net)

    sol = solve_static(net)
    print(f"Converged: {sol.converged} | Max |res|: {sol.max_abs_residual_W:.3e} W | Imbalance: {sol.global_energy_imbalance_W:.3e} W")
    for nid, t_val in sol.temperatures_K.items():
        print(f"  Node {nid:12s}: {t_val:7.2f} K  (res = {sol.residuals_W[nid]:+.3e} W)")
    for b in sol.branch_results:
        print(f"  Branch {b['id']:18s} ({b['from']} -> {b['to']}): {b['Q_from_to_W']:+.4f} W")
    if sol.warnings:
        print("Warnings:")
        for w in sol.warnings:
            print(" -", w)
    if args.export_csv:
        export_static_results_csv(sol, args.export_csv)


if __name__ == "__main__":
    main()
