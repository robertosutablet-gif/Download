from __future__ import annotations

import numpy as np
from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QPushButton,
    QLabel,
    QLineEdit,
    QComboBox,
    QCheckBox,
    QFileDialog,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
    QGroupBox,
    QFormLayout,
    QTextEdit,
    QDialog, QDialogButtonBox,
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from core.network import ThermalNetwork, ThermalBranch, HeatLoad
from physics.cryocooler import StageCapacityModel
from solvers.static import solve_static
from solvers.sizing import size_conduction_branch
from pathlib import Path as _Path
import importlib.util as _ilu
_pio_path = str(_Path(__file__).resolve().parent.parent / 'io' / 'project_io.py')
_pio_spec = _ilu.spec_from_file_location('project_io', _pio_path)
_pio_mod = _ilu.module_from_spec(_pio_spec)
_pio_spec.loader.exec_module(_pio_mod)
save_project_json = _pio_mod.save_project_json
load_project_json = _pio_mod.load_project_json
export_static_results_csv = _pio_mod.export_static_results_csv


class MplCanvas(FigureCanvas):
    def __init__(self, width: float = 6.0, height: float = 3.5, dpi: int = 100) -> None:
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)


class ThermalNetworkWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Rete Termica Magneti Superconduttori - v2.0")
        self.resize(1180, 780)
        self.network = ThermalNetwork.build_default_demo()
        self.last_solution = None

        root = QWidget()
        self.setCentralWidget(root)
        main_layout = QVBoxLayout(root)

        top_bar = QHBoxLayout()
        self.lbl_project = QLabel(f"Progetto: {self.network.name}")
        self.lbl_project.setStyleSheet("font-weight: bold;")
        btn_load_proj = QPushButton("Carica JSON")
        btn_save_proj = QPushButton("Salva JSON")
        btn_solve = QPushButton("Esegui Calcolo Statico")
        btn_solve.setStyleSheet("background-color: #1f6feb; color: white; font-weight: bold; padding: 6px 12px;")

        btn_load_proj.clicked.connect(self.on_load_project)
        btn_save_proj.clicked.connect(self.on_save_project)
        btn_solve.clicked.connect(self.on_solve_static)

        top_bar.addWidget(self.lbl_project)
        top_bar.addStretch()
        top_bar.addWidget(btn_load_proj)
        top_bar.addWidget(btn_save_proj)
        top_bar.addWidget(btn_solve)
        main_layout.addLayout(top_bar)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        self._build_tab_network()
        self._build_tab_materials()
        self._build_tab_cryocooler()
        self._build_tab_components()
        self._build_tab_loads_sizing()
        self._build_tab_results()

        self.refresh_all_ui()

    def _build_tab_network(self) -> None:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        form_box = QGroupBox("Aggiungi Ramo Termico")
        form = QHBoxLayout(form_box)
        self.edit_branch_id = QLineEdit("branch_custom")
        self.combo_branch_type = QComboBox()
        self.combo_branch_type.addItems(["conduction", "contact", "conduction_contact_series", "radiation", "mli"])
        self.combo_from = QComboBox()
        self.combo_to = QComboBox()
        self.combo_mat = QComboBox()
        self.edit_area = QLineEdit("1e-4")
        self.edit_length = QLineEdit("0.10")
        self.edit_cond_or_eps = QLineEdit("0.05")
        btn_add_br = QPushButton("Aggiungi Ramo")
        btn_add_br.clicked.connect(self.on_add_branch)

        for lbl, w in [
            ("ID", self.edit_branch_id),
            ("Tipo", self.combo_branch_type),
            ("Da", self.combo_from),
            ("A", self.combo_to),
            ("Mat", self.combo_mat),
            ("Area/Val1", self.edit_area),
            ("Lungh/Val2", self.edit_length),
            ("eps/G/P", self.edit_cond_or_eps),
        ]:
            form.addWidget(QLabel(lbl))
            form.addWidget(w)
        form.addWidget(btn_add_br)
        layout.addWidget(form_box)

        self.tbl_branches = QTableWidget(0, 6)
        self.tbl_branches.setHorizontalHeaderLabels(["ID", "Tipo", "Da", "A", "Attivo", "Parametri"])
        layout.addWidget(self.tbl_branches)

        self.tabs.addTab(tab, "Geometria e Rami")

    def _build_tab_materials(self) -> None:
        tab = QWidget()
        layout = QHBoxLayout(tab)

        left = QVBoxLayout()
        box = QGroupBox("Importa File Materiale (CSV / XLSX)")
        fl = QFormLayout(box)
        self.edit_mat_name = QLineEdit("")
        self.edit_mat_file = QLineEdit("")
        btn_browse_mat = QPushButton("Sfoglia file...")
        btn_browse_mat.clicked.connect(self.on_browse_material)
        file_row = QHBoxLayout()
        file_row.addWidget(self.edit_mat_file)
        file_row.addWidget(btn_browse_mat)

        self.combo_mat_interp = QComboBox()
        self.combo_mat_interp.addItems(["pchip", "linear"])
        self.chk_mat_extrap = QCheckBox("Consenti estrapolazione (sconsigliato)")
        btn_import_mat = QPushButton("Carica Materiale in Libreria")
        btn_import_mat.clicked.connect(self.on_import_material)

        fl.addRow("Nome materiale (opz.):", self.edit_mat_name)
        fl.addRow("File CSV/XLSX (col. T, k, cp):", file_row)
        fl.addRow("Interpolazione:", self.combo_mat_interp)
        fl.addRow("", self.chk_mat_extrap)
        fl.addRow("", btn_import_mat)
        left.addWidget(box)

        self.combo_mat_preview = QComboBox()
        self.combo_mat_preview.currentTextChanged.connect(self.plot_material_curve)
        left.addWidget(QLabel("Anteprima materiale:"))
        left.addWidget(self.combo_mat_preview)
        self.lbl_mat_info = QLabel("")
        self.lbl_mat_info.setWordWrap(True)
        left.addWidget(self.lbl_mat_info)
        left.addStretch()

        right = QVBoxLayout()
        self.mat_canvas = MplCanvas(6, 4)
        right.addWidget(self.mat_canvas)

        layout.addLayout(left, 1)
        layout.addLayout(right, 2)
        self.tabs.addTab(tab, "Materiali")

    def _build_tab_cryocooler(self) -> None:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        grp = QGroupBox("Cryocooler a Due Stadi - Caricamento Curve / Mappe CSV o XLSX")
        gl = QFormLayout(grp)
        self.edit_cc_model = QLineEdit(self.network.cryocooler.model_name)
        self.edit_cc_freq = QLineEdit(str(self.network.cryocooler.frequency_Hz))

        self.edit_s1_file = QLineEdit("")
        btn_s1 = QPushButton("Carica Mappa/Curva Stage 1")
        btn_s1.clicked.connect(lambda: self.on_load_stage_file(stage_idx=1))
        r1 = QHBoxLayout()
        r1.addWidget(self.edit_s1_file)
        r1.addWidget(btn_s1)

        self.edit_s2_file = QLineEdit("")
        btn_s2 = QPushButton("Carica Mappa/Curva Stage 2")
        btn_s2.clicked.connect(lambda: self.on_load_stage_file(stage_idx=2))
        r2 = QHBoxLayout()
        r2.addWidget(self.edit_s2_file)
        r2.addWidget(btn_s2)

        self.btn_manual_s1 = QPushButton("Inserisci curva Stage 1 da GUI")
        self.btn_manual_s2 = QPushButton("Inserisci curva Stage 2 da GUI")
        self.btn_manual_s1.clicked.connect(lambda: self.on_manual_stage_curve(1))
        self.btn_manual_s2.clicked.connect(lambda: self.on_manual_stage_curve(2))
        self.chk_cc_extrap = QCheckBox("Consenti estrapolazione fuori dominio (sconsigliato)")
        self.chk_cc_extrap.stateChanged.connect(self.on_toggle_cc_extrap)

        gl.addRow("Modello:", self.edit_cc_model)
        gl.addRow("Frequenza [Hz]:", self.edit_cc_freq)
        gl.addRow("Stage 1 file:", r1)
        gl.addRow("Stage 2 file:", r2)
        gl.addRow("", self.btn_manual_s1)
        gl.addRow("", self.btn_manual_s2)
        gl.addRow("", self.chk_cc_extrap)

        layout.addWidget(grp)
        self.lbl_cc_status = QLabel("")
        self.lbl_cc_status.setWordWrap(True)
        layout.addWidget(self.lbl_cc_status)
        layout.addStretch()

        self.tabs.addTab(tab, "Cryocooler")

    def _build_tab_components(self) -> None:
        tab=QWidget(); layout=QVBoxLayout(tab)
        box=QGroupBox("Current lead metallica – modello 1D ridotto")
        form=QFormLayout(box)
        self.lead_id=QLineEdit("current_lead_1")
        self.lead_from=QComboBox(); self.lead_to=QComboBox(); self.lead_mat=QComboBox()
        self.lead_area=QLineEdit("1e-6"); self.lead_length=QLineEdit("0.5"); self.lead_current=QLineEdit("100")
        for label,w in [("ID",self.lead_id),("Nodo caldo",self.lead_from),("Nodo freddo",self.lead_to),
                        ("Materiale (richiede rho_e(T))",self.lead_mat),("Sezione [m²]",self.lead_area),
                        ("Lunghezza [m]",self.lead_length),("Corrente [A]",self.lead_current)]: form.addRow(label,w)
        btn=QPushButton("Aggiungi current lead alla rete"); btn.clicked.connect(self.on_add_current_lead); form.addRow(btn)
        note=QLabel("Il modello calcola conduzione assiale e Joule I²R. La dissipazione Joule è ripartita 50/50 ai terminali: è un'approssimazione lumped, non una soluzione distribuita completa. Il materiale deve contenere k(T) e rho_e(T) in SI.")
        note.setWordWrap(True); layout.addWidget(box); layout.addWidget(note)
        contact=QGroupBox("Contatti termici – preset orientativi")
        cf=QFormLayout(contact)
        self.contact_preset=QComboBox(); self.contact_preset.addItems(["Cu-Cu_bare","manual"])
        self.contact_pressure=QLineEdit("3.8"); self.contact_area=QLineEdit("1e-4"); self.contact_exp=QLineEdit("0.8")
        cf.addRow("Coppia materiali",self.contact_preset); cf.addRow("Pressione [MPa]",self.contact_pressure); cf.addRow("Area [m²]",self.contact_area); cf.addRow("Esponente pressione (assunto, modificabile)",self.contact_exp)
        self.mli_preset=QComboBox(); self.mli_preset.addItems(["12-28 layers/cm: k_eff=3.5e-5 W/(m K) (limite basso)","12-28 layers/cm: k_eff=6.9e-5 W/(m K) (limite alto)","30-60 layers/cm: k_eff=1.73e-5 W/(m K)"])
        cf.addRow("Preset MLI evacuato",self.mli_preset)
        cnote=QLabel("Il preset numerico disponibile è Cu-Cu: letteratura riporta un intervallo ampio 220–1900 W/(m² K) fino a circa 3.8 MPa (10–130 K). Il valore nominale è un riferimento orientativo; l’esponente di pressione 0.8 è un’ipotesi modificabile, non un coefficiente universale. Altre coppie richiedono dati sperimentali o inserimento manuale. Per un collegamento bulk+contatto usare un ramo conduction_contact_series, non due rami paralleli.")
        cnote.setWordWrap(True); layout.addWidget(contact); layout.addWidget(cnote); layout.addStretch()
        self.tabs.addTab(tab,"Current leads e contatti")

    def _build_tab_loads_sizing(self) -> None:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        load_box = QGroupBox("Aggiungi Carico Termico [W]")
        ll = QHBoxLayout(load_box)
        self.edit_load_id = QLineEdit("load_extra")
        self.combo_load_node = QComboBox()
        self.edit_load_W = QLineEdit("0.5")
        self.edit_load_cat = QLineEdit("heater")
        btn_add_load = QPushButton("Aggiungi Carico")
        btn_add_load.clicked.connect(self.on_add_load)
        for lbl, w in [
            ("ID", self.edit_load_id),
            ("Nodo", self.combo_load_node),
            ("Potenza [W]", self.edit_load_W),
            ("Categoria", self.edit_load_cat),
        ]:
            ll.addWidget(QLabel(lbl))
            ll.addWidget(w)
        ll.addWidget(btn_add_load)
        layout.addWidget(load_box)

        self.tbl_loads = QTableWidget(0, 4)
        self.tbl_loads.setHorizontalHeaderLabels(["ID", "Nodo", "Potenza [W]", "Categoria"])
        layout.addWidget(self.tbl_loads)

        size_box = QGroupBox("Dimensionamento / Ottimizzazione Ramo di Conduzione")
        sl = QHBoxLayout(size_box)
        self.combo_size_branch = QComboBox()
        self.combo_size_node = QComboBox()
        self.edit_w_temp = QLineEdit("1.0")
        self.edit_w_power = QLineEdit("10.0")
        btn_size = QPushButton("Ottimizza Area e Lunghezza")
        btn_size.clicked.connect(self.on_optimize_branch)
        for lbl, w in [
            ("Ramo", self.combo_size_branch),
            ("Nodo obiettivo", self.combo_size_node),
            ("Peso T [1/K]", self.edit_w_temp),
            ("Peso |Q| [1/W]", self.edit_w_power),
        ]:
            sl.addWidget(QLabel(lbl))
            sl.addWidget(w)
        sl.addWidget(btn_size)
        layout.addWidget(size_box)

        self.tabs.addTab(tab, "Carichi e Dimensionamento")

    def _build_tab_results(self) -> None:
        tab = QWidget()
        layout = QHBoxLayout(tab)

        left = QVBoxLayout()
        self.tbl_results = QTableWidget(0, 3)
        self.tbl_results.setHorizontalHeaderLabels(["Nodo", "Temperatura [K]", "Residuo [W]"])
        left.addWidget(self.tbl_results)

        btn_exp = QPushButton("Esporta Risultati CSV")
        btn_exp.clicked.connect(self.on_export_csv)
        left.addWidget(btn_exp)

        self.txt_diag = QTextEdit()
        self.txt_diag.setReadOnly(True)
        self.txt_diag.setMaximumHeight(180)
        left.addWidget(self.txt_diag)

        right = QVBoxLayout()
        self.res_canvas = MplCanvas(6, 4)
        right.addWidget(self.res_canvas)

        layout.addLayout(left, 1)
        layout.addLayout(right, 1)
        self.tabs.addTab(tab, "Risultati")

    def refresh_all_ui(self) -> None:
        self.lbl_project.setText(f"Progetto: {self.network.name}")
        node_ids = list(self.network.nodes.keys())
        for cb in (self.combo_from, self.combo_to, self.combo_load_node, self.combo_size_node):
            cur = cb.currentText()
            cb.clear()
            cb.addItems(node_ids)
            if cur in node_ids:
                cb.setCurrentText(cur)

        mat_names = self.network.materials.list_names()
        for cb in (self.combo_mat, self.combo_mat_preview):
            cur = cb.currentText()
            cb.clear()
            cb.addItems(mat_names)
            if cur in mat_names:
                cb.setCurrentText(cur)

        cond_branches = [b.id for b in self.network.branches if b.branch_type == "conduction"]
        self.combo_size_branch.clear()
        self.combo_size_branch.addItems(cond_branches)

        self.tbl_branches.setRowCount(len(self.network.branches))
        for i, b in enumerate(self.network.branches):
            self.tbl_branches.setItem(i, 0, QTableWidgetItem(b.id))
            self.tbl_branches.setItem(i, 1, QTableWidgetItem(b.branch_type))
            self.tbl_branches.setItem(i, 2, QTableWidgetItem(b.from_node))
            self.tbl_branches.setItem(i, 3, QTableWidgetItem(b.to_node))
            self.tbl_branches.setItem(i, 4, QTableWidgetItem("SI" if b.enabled else "NO"))
            self.tbl_branches.setItem(i, 5, QTableWidgetItem(str(b.params)))

        self.tbl_loads.setRowCount(len(self.network.loads))
        for i, ld in enumerate(self.network.loads):
            self.tbl_loads.setItem(i, 0, QTableWidgetItem(ld.id))
            self.tbl_loads.setItem(i, 1, QTableWidgetItem(ld.node))
            self.tbl_loads.setItem(i, 2, QTableWidgetItem(f"{ld.power_W:.4f}"))
            self.tbl_loads.setItem(i, 3, QTableWidgetItem(ld.category))

        cc = self.network.cryocooler
        self.lbl_cc_status.setText(
            f"Stage 1 ({cc.stage1.mode}, file: {cc.stage1.source_file}) | "
            f"Stage 2 ({cc.stage2.mode}, file: {cc.stage2.source_file})"
        )
        self.plot_material_curve()

    def on_add_branch(self) -> None:
        try:
            btype = self.combo_branch_type.currentText()
            v1 = float(self.edit_area.text())
            v2 = float(self.edit_length.text())
            v3 = float(self.edit_cond_or_eps.text())
            if btype == "conduction":
                params = {"material": self.combo_mat.currentText(), "area_m2": v1, "length_m": v2}
            elif btype == "contact":
                if self.contact_preset.currentText()=="manual": params={"conductance_WK":v3}
                else: params = {"preset": self.contact_preset.currentText(), "pressure_MPa": float(self.contact_pressure.text()),
                          "pressure_exponent":float(self.contact_exp.text()), "area_m2": float(self.contact_area.text())}
            elif btype == "conduction_contact_series":
                params = {"material": self.combo_mat.currentText(), "area_m2": v1, "length_m": v2}
                if self.contact_preset.currentText()=="manual": params["conductance_WK"]=v3
                else: params.update({"preset":self.contact_preset.currentText(),"pressure_MPa":float(self.contact_pressure.text()),
                    "pressure_exponent":float(self.contact_exp.text()),"contact_area_m2":float(self.contact_area.text())})
            elif btype == "radiation":
                params = {"area_m2": v1, "emissivity_eff": v3, "view_factor": v2}
            else:
                mli_text=self.mli_preset.currentText()
                k_eff=1.73e-5 if "30-60" in mli_text else (6.9e-5 if "limite alto" in mli_text else 3.5e-5)
                params = {"mode": "effective_k_literature", "area_m2": v1, "effective_k_WmK": k_eff,
                          "thickness_m": max(v2, 1e-4), "literature_preset": mli_text}

            self.network.add_branch(
                ThermalBranch(
                    id=self.edit_branch_id.text().strip() or f"br_{len(self.network.branches)+1}",
                    branch_type=btype,
                    from_node=self.combo_from.currentText(),
                    to_node=self.combo_to.currentText(),
                    params=params,
                )
            )
            self.refresh_all_ui()
        except Exception as exc:
            QMessageBox.critical(self, "Errore ramo", str(exc))

    def on_manual_stage_curve(self, stage_idx: int) -> None:
        dlg=QDialog(self); dlg.setWindowTitle(f"Curva capacità frigorifera Stage {stage_idx}"); lay=QVBoxLayout(dlg)
        tbl=QTableWidget(8,2); tbl.setHorizontalHeaderLabels(["Temperatura [K]","Potenza frigorifera [W]"])
        model=self.network.cryocooler.stage1 if stage_idx==1 else self.network.cryocooler.stage2
        if model.T_curve is not None:
            tbl.setRowCount(max(8,len(model.T_curve)))
            for i,(t,q) in enumerate(zip(model.T_curve,model.Q_curve)):
                tbl.setItem(i,0,QTableWidgetItem(str(float(t)))); tbl.setItem(i,1,QTableWidgetItem(str(float(q))))
        lay.addWidget(QLabel("Inserire almeno due coppie T-Q. Le temperature devono essere univoche; potenza in W.")); lay.addWidget(tbl)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel); lay.addWidget(buttons)
        buttons.accepted.connect(dlg.accept); buttons.rejected.connect(dlg.reject)
        if dlg.exec()!=QDialog.DialogCode.Accepted: return
        try:
            ts=[]; qs=[]
            for r in range(tbl.rowCount()):
                a=tbl.item(r,0); b=tbl.item(r,1)
                if a is None and b is None: continue
                if a is None or b is None: raise ValueError(f"Riga {r+1}: inserire sia T sia Q.")
                ts.append(float(a.text())); qs.append(float(b.text()))
            new=StageCapacityModel.from_points(f"Stage {stage_idx}",ts,qs)
            if stage_idx==1: self.network.cryocooler.stage1=new
            else: self.network.cryocooler.stage2=new
            self.refresh_all_ui(); QMessageBox.information(self,"Curva aggiornata",f"Caricati {len(ts)} punti per Stage {stage_idx}.")
        except Exception as exc: QMessageBox.critical(self,"Errore curva",str(exc))

    def on_add_current_lead(self) -> None:
        try:
            p={"material":self.lead_mat.currentText(),"area_m2":float(self.lead_area.text()),
               "length_m":float(self.lead_length.text()),"current_A":float(self.lead_current.text())}
            # Verifica preventiva della presenza di rho_e(T).
            mat=self.network.materials.get(p["material"])
            if mat.rho_e is None: raise ValueError("Il materiale selezionato non contiene rho_e(T). Importare una tabella con colonna rho_e in ohm·m.")
            self.network.add_branch(ThermalBranch(id=self.lead_id.text().strip() or f"lead_{len(self.network.branches)+1}",
                branch_type="current_lead",from_node=self.lead_from.currentText(),to_node=self.lead_to.currentText(),params=p))
            self.refresh_all_ui(); QMessageBox.information(self,"Current lead", "Ramo aggiunto. Verificare il modello ridotto e i dati di resistività.")
        except Exception as exc: QMessageBox.critical(self,"Errore current lead",str(exc))

    def on_browse_material(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleziona file proprietà materiale", "", "Tabelle (*.csv *.xlsx *.xls)"
        )
        if path:
            self.edit_mat_file.setText(path)

    def on_import_material(self) -> None:
        try:
            fp = self.edit_mat_file.text().strip()
            name = self.edit_mat_name.text().strip() or None
            mat = self.network.materials.load_from_file(
                fp,
                name=name,
                interp_mode=self.combo_mat_interp.currentText(),
                allow_extrapolation=self.chk_mat_extrap.isChecked(),
            )
            self.refresh_all_ui()
            self.combo_mat_preview.setCurrentText(mat.name)
            QMessageBox.information(self, "Materiale caricato", f"Importato '{mat.name}' [{mat.t_min:.1f}–{mat.t_max:.1f} K].")
        except Exception as exc:
            QMessageBox.critical(self, "Errore import materiale", str(exc))

    def plot_material_curve(self) -> None:
        name = self.combo_mat_preview.currentText()
        if not name or name not in self.network.materials.materials:
            return
        mat = self.network.materials.get(name)
        self.lbl_mat_info.setText(
            f"Fonte: {mat.source} | Intervallo: [{mat.t_min:.2f}, {mat.t_max:.2f}] K | Interp: {mat.interp_mode}"
        )
        self.mat_canvas.ax.clear()
        t_grid = np.linspace(mat.t_min, mat.t_max, 200)
        if mat._k_eval is not None:
            self.mat_canvas.ax.plot(t_grid, mat.k_at(t_grid), label="k(T) [W/(m·K)]")
        if mat._cp_eval is not None:
            self.mat_canvas.ax.plot(t_grid, mat.cp_at(t_grid), label="cp(T) [J/(kg·K)]")
        self.mat_canvas.ax.set_xlabel("Temperatura [K]")
        self.mat_canvas.ax.grid(True, alpha=0.3)
        self.mat_canvas.ax.legend()
        self.mat_canvas.draw()

    def on_load_stage_file(self, stage_idx: int) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, f"Seleziona mappa/curva Cryocooler Stage {stage_idx}", "", "Tabelle (*.csv *.xlsx *.xls)"
        )
        if not path:
            return
        try:
            model = StageCapacityModel.from_csv(
                path,
                stage_name=f"Stage {stage_idx}",
                allow_extrapolation=self.chk_cc_extrap.isChecked(),
            )
            if stage_idx == 1:
                self.network.cryocooler.stage1 = model
                self.edit_s1_file.setText(path)
            else:
                self.network.cryocooler.stage2 = model
                self.edit_s2_file.setText(path)
            self.refresh_all_ui()
        except Exception as exc:
            QMessageBox.critical(self, "Errore mappa cryocooler", str(exc))

    def on_toggle_cc_extrap(self) -> None:
        allow = self.chk_cc_extrap.isChecked()
        self.network.cryocooler.stage1.allow_extrapolation = allow
        self.network.cryocooler.stage2.allow_extrapolation = allow

    def on_add_load(self) -> None:
        try:
            self.network.add_load(
                HeatLoad(
                    id=self.edit_load_id.text().strip() or f"load_{len(self.network.loads)+1}",
                    node=self.combo_load_node.currentText(),
                    power_W=float(self.edit_load_W.text()),
                    category=self.edit_load_cat.text().strip() or "internal",
                )
            )
            self.refresh_all_ui()
        except Exception as exc:
            QMessageBox.critical(self, "Errore carico", str(exc))

    def on_optimize_branch(self) -> None:
        try:
            res = size_conduction_branch(
                self.network,
                branch_id=self.combo_size_branch.currentText(),
                objective_node_id=self.combo_size_node.currentText(),
                weight_temp=float(self.edit_w_temp.text()),
                weight_power=float(self.edit_w_power.text()),
            )
            self.refresh_all_ui()
            QMessageBox.information(
                self,
                "Dimensionamento completato",
                f"Area ottima: {res.optimal_area_m2:.3e} m²\n"
                f"Lunghezza ottima: {res.optimal_length_m:.4f} m\n"
                f"T nodo obiettivo: {res.target_node_temp_K:.2f} K",
            )
            self.on_solve_static()
        except Exception as exc:
            QMessageBox.critical(self, "Errore dimensionamento", str(exc))

    def on_solve_static(self) -> None:
        try:
            self.network.cryocooler.model_name = self.edit_cc_model.text().strip() or "GM_TwoStage"
            self.network.cryocooler.frequency_Hz = int(float(self.edit_cc_freq.text()))
            sol = solve_static(self.network)
            self.last_solution = sol

            self.tbl_results.setRowCount(len(sol.temperatures_K))
            for i, (nid, t_val) in enumerate(sol.temperatures_K.items()):
                self.tbl_results.setItem(i, 0, QTableWidgetItem(nid))
                self.tbl_results.setItem(i, 1, QTableWidgetItem(f"{t_val:.3f}"))
                self.tbl_results.setItem(i, 2, QTableWidgetItem(f"{sol.residuals_W[nid]:+.3e}"))

            diag_lines = [
                f"Convergenza: {sol.converged} ({sol.message})",
                f"Max |residuo|: {sol.max_abs_residual_W:.3e} W | Sbilancio globale: {sol.global_energy_imbalance_W:+.3e} W",
                f"Stage summary: {sol.stage_summary}",
            ]
            for w in sol.warnings:
                diag_lines.append(f"[WARNING] {w}")
            for b in sol.branch_results:
                diag_lines.append(f"Ramo {b['id']} ({b['from']}->{b['to']}): {b['Q_from_to_W']:+.4f} W")
            self.txt_diag.setPlainText("\n".join(diag_lines))
            self.res_canvas.ax.set_title("Temperature Nodali a Regime Stazionario")
            self.res_canvas.ax.tick_params(axis="x", rotation=25)
            self.res_canvas.ax.grid(True, axis="y", alpha=0.3)
            self.res_canvas.draw()

            self.tabs.setCurrentIndex(5)
        except Exception as exc:
            QMessageBox.critical(self, "Errore solver statico", str(exc))

    def on_save_project(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Salva progetto JSON", "progetto_rete.json", "JSON (*.json)")
        if path:
            save_project_json(self.network, path)

    def on_load_project(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Carica progetto JSON", "", "JSON (*.json)")
        if path:
            load_project_json(path, self.network)
            self.refresh_all_ui()

    def on_export_csv(self) -> None:
        if self.last_solution is None:
            QMessageBox.warning(self, "Nessun risultato", "Esegui prima il calcolo statico.")
            return
        folder = QFileDialog.getExistingDirectory(self, "Seleziona cartella export CSV")
        if folder:
            export_static_results_csv(self.last_solution, folder)
            QMessageBox.information(self, "Export completato", f"File salvati in {folder}")
