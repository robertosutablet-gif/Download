from pathlib import Path
import subprocess, sys

root = Path(__file__).resolve().parent
py_exe = Path(sys.executable)
if py_exe.name.lower() == "pythonw.exe":
    candidate = py_exe.with_name("python.exe")
    if candidate.exists():
        py_exe = candidate

req_file = root / "requirements.txt"
cmd = [str(py_exe), "-m", "pip", "install"]
if req_file.exists():
    cmd += ["-r", str(req_file)]
else:
    cmd += ["numpy", "scipy", "pandas", "matplotlib", "openpyxl", "PySide6"]

res = subprocess.run(cmd, cwd=str(root), capture_output=True, text=True)
print("PIP EXIT CODE:", res.returncode)
print(res.stdout)
if res.returncode != 0:
    print("PIP ERRORE:\n", res.stderr)
else:
    cli_res = subprocess.run([str(py_exe), "run_cli.py"], cwd=str(root), capture_output=True, text=True)
    print("\n--- RISULTATO run_cli.py ---")
    print(cli_res.stdout)
    if cli_res.stderr:
        print(cli_res.stderr)
