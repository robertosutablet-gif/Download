# Rete Termica Magneti Superconduttori – versione corretta (base modulare)

## Avvio

```bash
python -m pip install -r requirements.txt
python run_gui.py
```

La GUI richiede PySide6 e Matplotlib. Il solver CLI è avviabile con `python run_cli.py`.

## Modifiche principali

- Curve cryocooler: importazione CSV/XLSX oppure inserimento manuale da GUI di coppie `T_K, Q_cap_W`. Le curve 1D sono interpolate con PCHIP; fuori dominio il calcolo si arresta per default. Se si abilita l'estrapolazione, viene usata una tangente lineare agli estremi e viene emesso un warning. Non viene ricostruita alcuna capacità frigorifera non fornita.
- Mappe 2D: seconda coordinata esplicitamente distinta tra temperatura dell'altro stadio (K) e carico dell'altro stadio (W). CSV con colonne `T_K`, `Q_cap_W` e `t_other_k` oppure `q_other_w`/`var2_w`.
- Current leads: nuovo tipo di ramo con geometria, corrente, materiale e proprietà `k(T)` e `rho_e(T)` importabili da CSV. Il calcolo è una riduzione lumped di un conduttore 1D: conduzione assiale integrata e Joule calcolato con resistività media lungo l'intervallo di temperatura, ripartito al 50% sui due nodi. Non equivale a una soluzione distribuita completa con profilo T(x), né a un modello HTS/metallico ottimizzato.
- MLI: aggiunto il modello `effective_k_literature`, con `Q = k_eff A (Th-Tc)/d`. Sono disponibili preset di k_eff indicativi riportati per MLI evacuato in letteratura/ASHRAE. I valori dipendono da temperatura, pressione, densità degli strati, spacers, seams, compressione e installazione; non sono una garanzia di prestazione per il blanket reale. Il vecchio modello parametrico rimane per compatibilità ma non va identificato automaticamente con una correlazione Lockheed validata.
- Contatti: preset numerico Cu-Cu bare con valore nominale orientativo, area e pressione impostabili. Il range di letteratura è ampio; l'esponente di pressione iniziale 0.8 è un parametro assunto e modificabile, non un esponente universale. Per altre coppie usare conduttanza misurata/inserita manualmente.
- Collegamenti bulk + interfaccia: nuovo ramo `conduction_contact_series`, che risolve la temperatura di interfaccia imponendo lo stesso flusso in conduzione e nel contatto. La presenza di rami `conduction` e `contact` paralleli sugli stessi due nodi genera un errore di validazione.
- Transitorio: i nodi con massa nulla sono trattati come nodi algebrici (bilancio stazionario risolto a ogni chiamata del sistema ODE); i nodi con massa positiva sono dinamici.
- Progetti: le curve 1D e le mappe 2D del cryocooler vengono salvate nel JSON, oltre ai parametri di rami e carichi.

## Formato dei file

### Curve cryocooler 1D

CSV con almeno due righe e colonne:

```csv
T_K,Q_cap_W
4.2,1.0
6.0,2.8
10.0,5.4
```

Le capacità devono essere non negative e le temperature univoche. I dati devono riferirsi alla frequenza, configurazione e condizioni dichiarate dal costruttore.

### Proprietà materiale per current leads

CSV con colonne `T`, `k`, `cp` e `rho_e`; unità SI: K, W/(m K), J/(kg K), ohm m. Per il ramo current lead sono obbligatorie `k(T)` e `rho_e(T)`. Non usare una resistività elettrica di rame generica se il materiale reale ha RRR, campo magnetico o composizione differenti.

## Limitazioni note/non validate

1. Il current lead è una rappresentazione lumped e ripartisce Joule in modo simmetrico. Per il progetto definitivo serve un BVP 1D/2D con condizioni termiche alle intercette e proprietà locali, ed eventualmente il modello elettrico della parte HTS.
2. I preset MLI e contatti sono valori preliminari di letteratura; devono essere sostituiti da misure o correlazioni corrispondenti alla specifica costruzione.
3. La mappa cryocooler non può essere estrapolata in modo fisicamente affidabile senza dati del costruttore. L'estrapolazione lineare o il nearest-neighbour della mappa 2D sono solo opzioni numeriche segnalate.
4. Il transitorio usa capacità termiche lumped `m cp(T)` e nodi algebrici; non include gradienti interni nelle masse, dipendenza del cryocooler dalla velocità di raffreddamento, né transitori interni del refrigeratore.
5. Le proprietà materiali integrate di default sono curve illustrative da verificare. Per analisi di progetto importare file tracciabili e documentati.
6. Il JSON salva i parametri e le mappe del cryocooler ma non incorpora ancora i file esterni di proprietà materiali: per riprodurre il progetto occorre conservare anche i CSV/XLSX dei materiali.
7. Non è stata eseguita una validazione sperimentale del modello complessivo su un magnete reale. La convergenza numerica non dimostra la correttezza fisica.

## Riferimenti per i preset

- ASHRAE Handbook – Cryogenics, tabelle sulle conducibilità apparenti di MLI evacuato (valori riportati per specifiche densità di strati e pressione residua).
- NASA, *Thermal Performance of Cryogenic Multilayer Insulation at Various Layer Spacings*, NASA NTRS document 20100034929: evidenzia la dipendenza da layer density, numero di strati, spacer e pressione.
- Mykhaylyk et al., *Thermal conductance of demountable in vacuum copper-copper joint between 14 and 100 K*, Rev. Sci. Instrum. 83, 034902 (2012), DOI: 10.1063/1.3697693.
- *Experimental estimation of thermal contact conductance across pressed copper-copper contacts at cryogenic-temperatures*, Applied Thermal Engineering 219 (2023), DOI: 10.1016/j.applthermaleng.2022.119412.
- *Thermal contact conductance of various metal interfaces at cryogenic temperature*, International Journal of Nanotechnology 16 (2019), DOI: 10.1504/IJNT.2019.104464.

I preset non sostituiscono i dati sperimentali dei contatti e del sistema MLI effettivamente costruito.
