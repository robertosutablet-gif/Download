from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any
import pandas as pd

from core.network import ThermalNetwork, ThermalNode, ThermalBranch, HeatLoad
from physics.cryocooler import StageCapacityModel
from solvers.static import StaticSolution


def save_project_json(network: ThermalNetwork, filepath: str | Path) -> None:
    payload: Dict[str, Any] = {
        "schema_version": "2.1",
        "project": {
            "name": network.name,
            "ambient_temperature_K": network.ambient_temp_K,
        },
        "cryocooler": {
            "model_name": network.cryocooler.model_name,
            "frequency_Hz": network.cryocooler.frequency_Hz,
            "stage1_node": network.cryocooler.stage1_node,
            "stage2_node": network.cryocooler.stage2_node,
            "stage1_source_file": network.cryocooler.stage1.source_file,
            "stage2_source_file": network.cryocooler.stage2.source_file,
            "stage1_curve_T_K": network.cryocooler.stage1.T_curve.tolist() if network.cryocooler.stage1.T_curve is not None else None,
            "stage1_curve_Q_W": network.cryocooler.stage1.Q_curve.tolist() if network.cryocooler.stage1.Q_curve is not None else None,
            "stage2_curve_T_K": network.cryocooler.stage2.T_curve.tolist() if network.cryocooler.stage2.T_curve is not None else None,
            "stage2_curve_Q_W": network.cryocooler.stage2.Q_curve.tolist() if network.cryocooler.stage2.Q_curve is not None else None,
            "stage1_allow_extrapolation": network.cryocooler.stage1.allow_extrapolation,
            "stage2_allow_extrapolation": network.cryocooler.stage2.allow_extrapolation,
            "stage1_mode": network.cryocooler.stage1.mode, "stage2_mode": network.cryocooler.stage2.mode,
            "stage1_map_x": network.cryocooler.stage1.map_x.tolist() if network.cryocooler.stage1.map_x is not None else None,
            "stage1_map_y": network.cryocooler.stage1.map_y.tolist() if network.cryocooler.stage1.map_y is not None else None,
            "stage1_map_z": network.cryocooler.stage1.map_z.tolist() if network.cryocooler.stage1.map_z is not None else None,
            "stage2_map_x": network.cryocooler.stage2.map_x.tolist() if network.cryocooler.stage2.map_x is not None else None,
            "stage2_map_y": network.cryocooler.stage2.map_y.tolist() if network.cryocooler.stage2.map_y is not None else None,
            "stage2_map_z": network.cryocooler.stage2.map_z.tolist() if network.cryocooler.stage2.map_z is not None else None,
            "stage1_map_y_name": network.cryocooler.stage1.map_y_name, "stage2_map_y_name": network.cryocooler.stage2.map_y_name,
            "stage1_map_y_unit": network.cryocooler.stage1.map_y_unit, "stage2_map_y_unit": network.cryocooler.stage2.map_y_unit,
        },
        "nodes": [
            {
                "id": n.id,
                "node_type": n.node_type,
                "fixed_temp_K": n.fixed_temp_K,
                "material": n.material,
                "mass_kg": n.mass_kg,
                "target_temp_K": n.target_temp_K,
            }
            for n in network.nodes.values()
        ],
        "branches": [
            {
                "id": b.id,
                "branch_type": b.branch_type,
                "from_node": b.from_node,
                "to_node": b.to_node,
                "enabled": b.enabled,
                "params": b.params,
            }
            for b in network.branches
        ],
        "loads": [
            {
                "id": ld.id,
                "node": ld.node,
                "power_W": ld.power_W,
                "category": ld.category,
                "source": ld.source,
                "enabled": ld.enabled,
            }
            for ld in network.loads
        ],
    }
    Path(filepath).write_text(json.dumps(payload, indent=2), encoding="utf-8")


def load_project_json(filepath: str | Path, network: ThermalNetwork) -> ThermalNetwork:
    data = json.loads(Path(filepath).read_text(encoding="utf-8"))
    proj = data.get("project", {})
    network.name = proj.get("name", network.name)
    network.ambient_temp_K = float(proj.get("ambient_temperature_K", network.ambient_temp_K))

    cc = data.get("cryocooler", {})
    network.cryocooler.model_name = cc.get("model_name", network.cryocooler.model_name)
    network.cryocooler.frequency_Hz = int(cc.get("frequency_Hz", network.cryocooler.frequency_Hz))
    network.cryocooler.stage1_node = cc.get("stage1_node", network.cryocooler.stage1_node)
    network.cryocooler.stage2_node = cc.get("stage2_node", network.cryocooler.stage2_node)
    for idx in (1,2):
        t=cc.get(f"stage{idx}_curve_T_K"); q=cc.get(f"stage{idx}_curve_Q_W")
        mode=cc.get(f"stage{idx}_mode","1d_curve")
        if mode=="2d_map" and cc.get(f"stage{idx}_map_x") is not None:
            model=StageCapacityModel(stage_name=f"Stage {idx}",mode="2d_map",map_x=cc[f"stage{idx}_map_x"],map_y=cc[f"stage{idx}_map_y"],map_z=cc[f"stage{idx}_map_z"],map_y_name=cc.get(f"stage{idx}_map_y_name","var2"),map_y_unit=cc.get(f"stage{idx}_map_y_unit","W"),source_file=cc.get(f"stage{idx}_source_file","project JSON"))
            setattr(network.cryocooler,f"stage{idx}",model)
        elif t is not None and q is not None:
            setattr(network.cryocooler,f"stage{idx}",StageCapacityModel.from_points(f"Stage {idx}",t,q,source_file=cc.get(f"stage{idx}_source_file","project JSON")))
        getattr(network.cryocooler,f"stage{idx}").allow_extrapolation=bool(cc.get(f"stage{idx}_allow_extrapolation",False))

    network.nodes.clear()
    for nd in data.get("nodes", []):
        network.add_node(
            ThermalNode(
                id=nd["id"],
                node_type=nd.get("node_type", "thermal_mass"),
                fixed_temp_K=nd.get("fixed_temp_K"),
                material=nd.get("material"),
                mass_kg=float(nd.get("mass_kg", 0.0)),
                target_temp_K=nd.get("target_temp_K"),
            )
        )

    network.branches.clear()
    for br in data.get("branches", []):
        network.add_branch(
            ThermalBranch(
                id=br["id"],
                branch_type=br["branch_type"],
                from_node=br["from_node"],
                to_node=br["to_node"],
                enabled=bool(br.get("enabled", True)),
                params=br.get("params", {}),
            )
        )

    network.loads.clear()
    for ld in data.get("loads", []):
        network.add_load(
            HeatLoad(
                id=ld["id"],
                node=ld["node"],
                power_W=float(ld["power_W"]),
                category=ld.get("category", "internal"),
                source=ld.get("source", "json"),
                enabled=bool(ld.get("enabled", True)),
            )
        )
    return network


def export_static_results_csv(sol: StaticSolution, out_dir: str | Path) -> None:
    d = Path(out_dir)
    d.mkdir(parents=True, exist_ok=True)
    nodes_df = pd.DataFrame(
        [
            {
                "node_id": nid,
                "temperature_K": sol.temperatures_K[nid],
                "residual_W": sol.residuals_W[nid],
            }
            for nid in sol.temperatures_K
        ]
    )
    nodes_df.to_csv(d / "nodes_results.csv", index=False)
    pd.DataFrame(sol.branch_results).to_csv(d / "branches_results.csv", index=False)
