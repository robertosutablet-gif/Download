import sys
from PySide6.QtWidgets import QApplication
from app_gui.main_window import ThermalNetworkWindow

if __name__ == "__main__":
    app=QApplication(sys.argv)
    win=ThermalNetworkWindow(); win.show()
    sys.exit(app.exec())
