from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Tuple
import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator, LinearNDInterpolator

@dataclass
class StageCapacityModel:
    stage_name: str
    T_curve: Optional[np.ndarray] = None
    Q_curve: Optional[np.ndarray] = None
    mode: str = "1d_curve"
    map_x: Optional[np.ndarray] = None
    map_y: Optional[np.ndarray] = None
    map_z: Optional[np.ndarray] = None
    map_y_name: str = "var2"
    map_y_unit: str = "W"
    allow_extrapolation: bool = False
    source_file: str = "built-in"
    _pchip_1d: Optional[PchipInterpolator] = field(default=None, repr=False)
    _nd_interp: Optional[LinearNDInterpolator] = field(default=None, repr=False)

    def __post_init__(self):
        if self.mode == "1d_curve" and self.T_curve is not None and self.Q_curve is not None:
            t=np.asarray(self.T_curve,float); q=np.asarray(self.Q_curve,float)
            if t.size < 2 or q.size != t.size or not np.all(np.isfinite(t)) or not np.all(np.isfinite(q)):
                raise ValueError("Curva cryocooler: servono almeno due coppie T-Q finite.")
            idx=np.argsort(t); t,q=t[idx],q[idx]
            if np.any(np.diff(t)<=0) or np.any(q<0): raise ValueError("Temperature duplicate o capacità negativa nella curva cryocooler.")
            self.T_curve,self.Q_curve=t,q
            self._pchip_1d=PchipInterpolator(t,q,extrapolate=False)
        elif self.mode == "2d_map" and self.map_x is not None:
            x=np.asarray(self.map_x,float); y=np.asarray(self.map_y,float); z=np.asarray(self.map_z,float)
            if len(x)<3 or not (len(x)==len(y)==len(z)): raise ValueError("Mappa 2D: servono almeno tre punti coerenti.")
            self.map_x,self.map_y,self.map_z=x,y,z
            self._nd_interp=LinearNDInterpolator(np.column_stack([x,y]),z)

    @classmethod
    def from_csv(cls, filepath: str|Path, stage_name: str, allow_extrapolation=False, sheet_name=None):
        path=Path(filepath)
        if not path.exists(): raise FileNotFoundError(path)
        df=pd.read_excel(path,sheet_name=sheet_name or 0) if path.suffix.lower() in {'.xlsx','.xls'} else pd.read_csv(path)
        df.columns=[str(c).strip() for c in df.columns]; low={c.lower():c for c in df.columns}
        tc=next((low[k] for k in ('t_k','temperature_k','t','temp_k') if k in low),None)
        qc=next((low[k] for k in ('q_cap_w','capacity_w','q_w','q_watt') if k in low),None)
        if not tc or not qc: raise ValueError("CSV curva 1D: colonne richieste T_K e Q_cap_W.")
        # Le mappe 2D devono dichiarare esplicitamente la coordinata y e la sua unità.
        ycol=next((low[k] for k in ('var2_w','q_other_w','other_stage_load_w','t_other_k','t2_k') if k in low),None)
        if ycol:
            yname='other_stage_temperature' if 't' in ycol.lower() else 'other_stage_load'
            yunit='K' if yname.endswith('temperature') else 'W'
            x=pd.to_numeric(df[tc],errors='coerce').to_numpy(float); y=pd.to_numeric(df[ycol],errors='coerce').to_numpy(float); z=pd.to_numeric(df[qc],errors='coerce').to_numpy(float)
            m=np.isfinite(x)&np.isfinite(y)&np.isfinite(z)
            return cls(stage_name,mode='2d_map',map_x=x[m],map_y=y[m],map_z=z[m],map_y_name=yname,map_y_unit=yunit,allow_extrapolation=allow_extrapolation,source_file=str(path))
        x=pd.to_numeric(df[tc],errors='coerce').to_numpy(float); q=pd.to_numeric(df[qc],errors='coerce').to_numpy(float); m=np.isfinite(x)&np.isfinite(q)
        return cls(stage_name,T_curve=x[m],Q_curve=q[m],allow_extrapolation=allow_extrapolation,source_file=str(path))

    @classmethod
    def from_points(cls, stage_name, temperatures_K, capacities_W, source_file='GUI manual input'):
        return cls(stage_name,T_curve=np.asarray(temperatures_K,float),Q_curve=np.asarray(capacities_W,float),source_file=source_file)

    def capacity_W(self,T_stage:float,var2:float=0.0):
        if not np.isfinite(T_stage): raise ValueError("Temperatura cryocooler non valida.")
        if self.mode=='1d_curve':
            if self._pchip_1d is None: raise ValueError(f"Curva {self.stage_name} non configurata.")
            lo,hi=float(self.T_curve[0]),float(self.T_curve[-1])
            if not lo<=T_stage<=hi:
                msg=f"{self.stage_name}: T={T_stage:.3f} K fuori curva [{lo:.3f}, {hi:.3f}] K."
                if not self.allow_extrapolation: raise ValueError(msg)
                # Extrapolazione lineare tangente agli estremi, esplicita e non clamping.
                i=0 if T_stage<lo else -1; slope=float(self._pchip_1d.derivative()(self.T_curve[i])); val=float(self.Q_curve[i]+slope*(T_stage-self.T_curve[i]))
                return max(0.0,val),msg+" Estrapolazione lineare tangente; verificare fisicamente."
            return max(0.0,float(self._pchip_1d(T_stage))),None
        if self._nd_interp is None: raise ValueError(f"Mappa 2D {self.stage_name} non configurata.")
        val=float(self._nd_interp([[T_stage,var2]])[0])
        if not np.isfinite(val):
            msg=f"{self.stage_name}: punto (T={T_stage:.3f} K, {self.map_y_name}={var2:.3f} {self.map_y_unit}) fuori inviluppo mappa."
            if not self.allow_extrapolation: raise ValueError(msg)
            sx=max(float(np.ptp(self.map_x)),1e-12); sy=max(float(np.ptp(self.map_y)),1e-12)
            idx=int(np.argmin(((self.map_x-T_stage)/sx)**2+((self.map_y-var2)/sy)**2))
            return max(0.0,float(self.map_z[idx])),msg+" Valore del punto sperimentale più vicino su assi normalizzati (non vera estrapolazione)."
        return max(0.0,val),None

@dataclass
class TwoStageCryocooler:
    model_name: str="GM_TwoStage_Generic"
    frequency_Hz: int=50
    stage1_node: str="stage1"
    stage2_node: str="stage2"
    stage1: StageCapacityModel=field(default_factory=lambda:StageCapacityModel("Stage 1",T_curve=np.array([25.,35.,45.,60.,80.,100.]),Q_curve=np.array([5.,18.,30.,42.,52.,60.]),source_file='illustrative_default_NOT_MANUFACTURER_DATA'))
    stage2: StageCapacityModel=field(default_factory=lambda:StageCapacityModel("Stage 2",T_curve=np.array([3.5,4.2,6.,10.,15.,20.]),Q_curve=np.array([.2,1.,2.8,5.4,8.2,10.5]),source_file='illustrative_default_NOT_MANUFACTURER_DATA'))
