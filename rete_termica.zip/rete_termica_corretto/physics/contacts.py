from __future__ import annotations

# Preset orientativi di conduttanza areica h_c [W/(m² K)] a pressione di
# riferimento. Non sono correlazioni universali né sostituiscono misure del giunto.
# Cu-Cu: letteratura cryogenica riporta valori molto dipendenti da T, pressione,
# rugosità e finitura; range 220-1900 W/(m² K) fino a circa 3.8 MPa (10-130 K).
_CONTACT_PRESETS = {
    "Cu-Cu_bare": {"h_ref": 800.0, "p_ref_MPa": 3.8, "exponent": 0.8, "range": "220-1900 W/(m² K), 10-130 K; valore nominale 800 non è un dato misurato puntuale"},
}

def preset_contact_conductance(preset: str, pressure_MPa: float, area_m2: float, pressure_exponent: float = 0.8) -> float:
    if preset not in _CONTACT_PRESETS: raise ValueError(f"Preset contatto sconosciuto: {preset}")
    if pressure_MPa <= 0 or area_m2 <= 0: raise ValueError("Pressione e area di contatto devono essere positive.")
    d=_CONTACT_PRESETS[preset]
    h=d['h_ref']*(pressure_MPa/d['p_ref_MPa'])**float(pressure_exponent)
    return h*area_m2

def contact_heat_flow(T_a: float,T_b: float,conductance_WK:float|None=None,resistance_KW:float|None=None)->float:
    if conductance_WK is not None and conductance_WK>0: g=float(conductance_WK)
    elif resistance_KW is not None and resistance_KW>0: g=1.0/float(resistance_KW)
    else: raise ValueError("Specificare conductance_WK > 0 oppure resistance_KW > 0.")
    return g*(T_a-T_b)
