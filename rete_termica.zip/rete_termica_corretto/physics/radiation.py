from __future__ import annotations

SIGMA_SB = 5.670374419e-8  # W / (m^2 K^4)


def radiation_heat_flow(
    T_a: float,
    T_b: float,
    area_m2: float,
    emissivity_eff: float,
    view_factor: float = 1.0,
) -> float:
    if area_m2 < 0.0:
        raise ValueError("Area radiativa non può essere negativa.")
    if not (0.0 <= emissivity_eff <= 1.0):
        raise ValueError("Emissività efficace deve essere in [0, 1].")
    if not (0.0 <= view_factor <= 1.0):
        raise ValueError("Fattore di vista F deve essere in [0, 1].")
    return emissivity_eff * SIGMA_SB * area_m2 * view_factor * (T_a**4 - T_b**4)
