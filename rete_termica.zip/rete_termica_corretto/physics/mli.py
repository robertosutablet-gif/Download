from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import numpy as np
import pandas as pd
from scipy.interpolate import LinearNDInterpolator


@dataclass
class MLIModel:
    mode: str = "parametric_modified_lockheed"
    area_m2: float = 1.0
    layers: int = 30
    layer_density_per_cm: float = 20.0
    residual_pressure_Pa: float = 1e-4
    emissivity_eff: float = 0.015
    c_rad: float = 1.2e-7
    c_solid: float = 8.0e-4
    c_gas: float = 0.05
    parasitic_W: float = 0.0
    allow_extrapolation: bool = False
    exp_csv_path: Optional[str] = None
    effective_k_WmK: float = 3.5e-5
    thickness_m: float = 0.03
    _interp: Optional[LinearNDInterpolator] = None

    def __post_init__(self) -> None:
        if self.mode == "experimental_csv" and self.exp_csv_path:
            self.load_experimental_csv(self.exp_csv_path)

    def load_experimental_csv(self, filepath: str | Path) -> None:
        path = Path(filepath)
        df = pd.read_csv(path)
        cols = {c.lower().strip(): c for c in df.columns}
        for req in ("th_k", "tc_k", "q_flux_wm2"):
            if req not in cols:
                raise ValueError(f"CSV MLI '{path.name}' richiede colonna '{req}'. Trovate: {list(df.columns)}")
        th = pd.to_numeric(df[cols["th_k"]], errors="coerce").to_numpy(dtype=float)
        tc = pd.to_numeric(df[cols["tc_k"]], errors="coerce").to_numpy(dtype=float)
        q_flux = pd.to_numeric(df[cols["q_flux_wm2"]], errors="coerce").to_numpy(dtype=float)
        mask = np.isfinite(th) & np.isfinite(tc) & np.isfinite(q_flux)
        pts = np.column_stack([th[mask], tc[mask]])
        self._interp = LinearNDInterpolator(pts, q_flux[mask])

    def heat_flow(self, T_a: float, T_b: float) -> float:
        if abs(T_a - T_b) < 1e-12:
            return 0.0
        sign = 1.0 if T_a > T_b else -1.0
        Th = max(T_a, T_b)
        Tc = min(T_a, T_b)

        if self.mode == "experimental_csv":
            if self._interp is None:
                raise ValueError("Modalità MLI sperimentale attiva ma tabella non caricata.")
            q_flux = float(self._interp(Th, Tc))
            if np.isnan(q_flux):
                if not self.allow_extrapolation:
                    raise ValueError(f"MLI sperimentale: punto (Th={Th:.1f} K, Tc={Tc:.1f} K) fuori dominio.")
                q_flux = 0.5 * (Th**4 - Tc**4) * 1e-9
            return sign * (q_flux * self.area_m2 + self.parasitic_W)

        if self.mode == "effective_k_literature":
            if self.effective_k_WmK <= 0 or self.thickness_m <= 0:
                raise ValueError("MLI effective-k: k_eff e spessore devono essere positivi.")
            q = self.effective_k_WmK * self.area_m2 * (Th-Tc) / self.thickness_m
            return sign * (q + self.parasitic_W)

        if self.mode == "emissivity_eff":
            sigma = 5.670374419e-8
            q_rad = self.emissivity_eff * sigma * self.area_m2 * (Th**4 - Tc**4)
            return sign * (q_rad + self.parasitic_W)

        n_lay = max(int(self.layers), 1)
        q_rad = (self.c_rad * (Th**4 - Tc**4)) / (n_lay**0.85)
        rho_factor = max(self.layer_density_per_cm / 20.0, 0.1)
        t_avg = 0.5 * (Th + Tc)
        q_solid = (self.c_solid * (rho_factor**1.5) * (t_avg / 300.0) * (Th - Tc)) / n_lay
        p_pa = max(self.residual_pressure_Pa, 0.0)
        q_gas = self.c_gas * p_pa * (Th - Tc)

        q_total = (q_rad + q_solid + q_gas) * self.area_m2 + self.parasitic_W
        return sign * q_total
