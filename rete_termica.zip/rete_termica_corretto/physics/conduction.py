from __future__ import annotations
from materials.library import MaterialCurve


def conduction_heat_flow(
    T_a: float,
    T_b: float,
    area_m2: float,
    length_m: float,
    material: MaterialCurve,
) -> float:
    if area_m2 <= 0.0 or length_m <= 0.0:
        raise ValueError("Area [m^2] e lunghezza [m] di conduzione devono essere > 0.")
    if abs(T_a - T_b) < 1e-12:
        return 0.0
    T_cold = min(T_a, T_b)
    T_hot = max(T_a, T_b)
    integral_k = material.integrate_k(T_cold, T_hot)
    mag = (area_m2 / length_m) * integral_k
    return mag if T_a > T_b else -mag
