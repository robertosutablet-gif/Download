from __future__ import annotations
import numpy as np


def current_lead_terms(Ta: float, Tb: float, *, area_m2: float, length_m: float,
                       current_A: float, material, n_points: int = 31):
    """Lumped 1-D lead approximation.

    Axial conduction uses integral(k dT) A/L. Joule power is evaluated as
    I² L/A times the length-average rho_e(T), and split equally between nodes.
    This is a reduced-order model, not a distributed BVP solution.
    Returns (Q_a_to_b_W, total_Joule_W).
    """
    if area_m2 <= 0 or length_m <= 0 or current_A < 0:
        raise ValueError("Current lead: area/lunghezza devono essere positive e corrente non negativa.")
    q_cond = 0.0 if abs(Ta-Tb)<1e-12 else (area_m2/length_m)*material.integrate_k(min(Ta,Tb),max(Ta,Tb))*(1 if Ta>Tb else -1)
    if material.rho_e is None:
        raise ValueError(f"Materiale '{material.name}' privo di resistività elettrica rho_e(T): impossibile calcolare Joule.")
    t=np.linspace(min(Ta,Tb),max(Ta,Tb),max(3,int(n_points)))
    rho=np.asarray(material.rho_e_at(t),float)
    if np.any(~np.isfinite(rho)) or np.any(rho<0): raise ValueError("rho_e(T) non valida per current lead.")
    rho_avg=float(np.trapezoid(rho,t)/(t[-1]-t[0])) if t[-1]>t[0] else float(rho[0])
    q_joule=current_A**2 * length_m/area_m2 * rho_avg
    return float(q_cond),float(q_joule)
